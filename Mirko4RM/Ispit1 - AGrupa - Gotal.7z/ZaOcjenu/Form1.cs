﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ZaOcjenu {
    public partial class Form1 : Form {
        class Naselje {
            int id;
            String naziv;
            int postanskiBroj;
            Zupanija zupanija;
            public Naselje(String naziv, int pb, Zupanija zupanija) {
                this.naziv = naziv;
                postanskiBroj = pb;
                this.zupanija = zupanija;
            }
        }
        class Zupanija {
            int id;
            public string naziv { private set; get; }
            public Zupanija(string n) {
                naziv = n;

            }
        }

        class Zaposlenik {
            int id;
            int oib;
            String ime;
            String prezime;
            Naselje naselje;
            String ulica;
            public Zaposlenik(int oib,
            String ime,
            String prezime,
            Naselje naselje,
            String ulica) {
                this.oib= oib;
                this.ime = ime;
                this.prezime = prezime;
                this.naselje = naselje;
                this.ulica = ulica;
            }
        }
        List<Zaposlenik> zaposleniks= new List<Zaposlenik>();
        List<Naselje> naseljes = new List<Naselje>();
        List<Zupanija> zupanijas = new List<Zupanija>();
        public Form1() {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {
            //SqlConnection sqlConnection = new SqlConnection("@Instance=192.168.Catalog");

        }

        private void button1_Click(object sender, EventArgs e) {
            if (comboBox1.SelectedIndex == -1) {
                MessageBox.Show("Odaberi naselje");
                return;
            }
            try {
                int.Parse(textBox1.Text);
            } catch {
                MessageBox.Show("OIB broj");
                return;
            }
            zaposleniks.Add(new Zaposlenik(int.Parse(textBox1.Text), textBox2.Text, textBox3.Text, naseljes[comboBox1.SelectedIndex], textBox4.Text));
            listBox1.Items.Add(textBox2.Text + " " + textBox3.Text + " " + textBox1.Text);
            
        }

        private void button2_Click(object sender, EventArgs e) {
            if (comboBox2.SelectedIndex == -1) {
                MessageBox.Show("Odaberi županiju");
                return;
            }
            try {
                Int32.Parse(textBox6.Text);
            } catch {
                MessageBox.Show("Poštanski broj je broj!");
                return;
            }
            naseljes.Add(new Naselje(textBox5.Text, Int32.Parse(textBox6.Text), zupanijas[comboBox2.SelectedIndex]));
            comboBox1.Items.Add(textBox5.Text +" "+ Int32.Parse(textBox6.Text)+" "+ zupanijas[comboBox2.SelectedIndex].naziv);
        }

        private void button3_Click(object sender, EventArgs e) {
            if (textBox7.Text != "")
                zupanijas.Add(new Zupanija(textBox7.Text));
            listBox2.Items.Add(textBox7.Text);
            comboBox2.Items.Add(textBox7.Text);
        }

        private void button4_Click(object sender, EventArgs e) {

            if (listBox2.SelectedIndex == -1) {
                MessageBox.Show("Odaberi županiju");
                return;
            }
            zupanijas.RemoveAt(listBox2.SelectedIndex);

            listBox2.Items.Clear();
            comboBox2.Items.Clear();
            foreach (Zupanija zupanija in zupanijas) {
                listBox2.Items.Add(zupanija.naziv);
                comboBox2.Items.Add(zupanija.naziv);
            }

        }
    }
}
