﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        Console.WriteLine("Fetching a random joke...");

        using (var client = new HttpClient()) 
        {
            client.DefaultRequestHeaders.Add("User-Agent", "CSharpApp");

            try
            {
                string url = "https://official-joke-api.appspot.com/random_joke";
                string json = await client.GetStringAsync(url);

                Console.WriteLine("\nHere’s your joke:");
                Console.WriteLine(json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Something went wrong: {ex.Message}");
            }
        }
    }
}
