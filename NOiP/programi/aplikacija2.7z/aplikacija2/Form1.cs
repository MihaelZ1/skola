﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija2
{
    public partial class Form1 : Form
    {
        private CancellationTokenSource cts;
        private delegate void UpdateStatusDelegate(string status);

        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (!IPAddress.TryParse(txtIP.Text.Trim(), out IPAddress ipAddress))
            {
                MessageBox.Show("Unesite ispravnu IP adresu.");
                return;
            }

            if (!int.TryParse(txtPort.Text.Trim(), out int port) || port < 1 || port > 65535)
            {
                MessageBox.Show("Unesite ispravan broj porta (1-65535).");
                return;
            }

            string expected = txtExpectedMessage.Text;
            string response = txtResponseMessage.Text;

            if (radioTCP.Checked)
                StartTcpServer(ipAddress, port, expected, response);
            else if (radioUDP.Checked)
                StartUdpServer(ipAddress, port, expected, response);
            else
                MessageBox.Show("Odaberite TCP ili UDP protokol.");
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            cts?.Cancel();
            lblStatus.Text = "Servis zaustavljen.";
        }
        private void StartTcpServer(IPAddress ipAddress, int port, string expected, string response)
        {
            cts = new CancellationTokenSource();
            lblStatus.Text = $"TCP servis pokrenut na {ipAddress}:{port}";

            Task.Run(async () =>
            {
                try
                {
                    TcpListener listener = new TcpListener(ipAddress, port);
                    listener.Start();

                    while (!cts.Token.IsCancellationRequested)
                    {
                        if (listener.Pending())
                        {
                            TcpClient client = await listener.AcceptTcpClientAsync();
                            _ = Task.Run(async () =>
                            {
                                using (var stream = client.GetStream())
                                {
                                    byte[] buffer = new byte[1024];
                                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                                    string received = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                                    // Poziv Invoke s delegate-om
                                    Invoke(new UpdateStatusDelegate((status) => lblStatus.Text = status), $"Primljeno: {received}");

                                    if (received.Trim() == expected)
                                    {
                                        byte[] reply = Encoding.UTF8.GetBytes(response);
                                        await stream.WriteAsync(reply, 0, reply.Length);
                                    }
                                }
                                client.Close();
                            });
                        }

                        await Task.Delay(100);
                    }

                    listener.Stop();
                }
                catch (Exception ex)
                {
                    // Poziv Invoke s delegate-om za grešku
                    Invoke(new UpdateStatusDelegate((status) => lblStatus.Text = status), "Greška: " + ex.Message);
                }
            });
        }

        private void StartUdpServer(IPAddress ipAddress, int port, string expected, string response)
        {
            cts = new CancellationTokenSource();
            lblStatus.Text = $"UDP servis pokrenut na {ipAddress}:{port}";

            Task.Run(async () =>
            {
                try
                {
                    UdpClient udp = new UdpClient(new IPEndPoint(ipAddress, port));

                    while (!cts.Token.IsCancellationRequested)
                    {
                        if (udp.Available > 0)
                        {
                            var result = await udp.ReceiveAsync();
                            string received = Encoding.UTF8.GetString(result.Buffer);

                            // Poziv Invoke s delegate-om
                            Invoke(new UpdateStatusDelegate((status) => lblStatus.Text = status), $"Primljeno: {received}");

                            if (received.Trim() == expected)
                            {
                                byte[] reply = Encoding.UTF8.GetBytes(response);
                                await udp.SendAsync(reply, reply.Length, result.RemoteEndPoint);
                            }
                        }

                        await Task.Delay(100);
                    }

                    udp.Close();
                }
                catch (Exception ex)
                {
                    // Poziv Invoke s delegate-om za grešku
                    Invoke(new UpdateStatusDelegate((status) => lblStatus.Text = status), "Greška: " + ex.Message);
                }
            });
        }
    }
}
