﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private async void btnStart_Click(object sender, EventArgs e)
        {
            listBoxSuccess.Items.Clear();
            listBoxFail.Items.Clear();

            var ipList = txtIPList.Text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            string protocol = radioTCP.Checked ? "TCP" : (radioUDP.Checked ? "UDP" : null);
            string messageToSend = txtSendMessage.Text;
            string expectedResponse = txtExpectedResponse.Text;

            if (!int.TryParse(txtPortRangeFrom.Text.Trim(), out int startPort) ||
                !int.TryParse(txtPortRangeTo.Text.Trim(), out int endPort))
            {
                MessageBox.Show("Unesi ispravne cijele brojeve za portove (od - do).");
                return;
            }

            if (startPort > endPort)
            {
                MessageBox.Show("Početni port ne može biti veći od završnog porta.");
                return;
            }

            if (string.IsNullOrWhiteSpace(protocol))
            {
                MessageBox.Show("Odaberi TCP ili UDP.");
                return;
            }

            foreach (var ip in ipList)
            {
                if (!IPAddress.TryParse(ip.Trim(), out IPAddress ipAddress))
                {
                    listBoxFail.Items.Add($"{ip}: Neispravna IP adresa.");
                    continue;
                }

                for (int port = startPort; port <= endPort; port++)
                {
                    if (protocol == "TCP")
                        await TestTcp(ipAddress, port, messageToSend, expectedResponse);
                    else
                        await TestUdp(ipAddress, port, messageToSend, expectedResponse);
                }
            }
        }
        private async Task TestTcp(IPAddress ip, int port, string message, string expected)
        {
            try
            {
                using (TcpClient client = new TcpClient())
                {
                    var connectTask = client.ConnectAsync(ip, port);
                    if (await Task.WhenAny(connectTask, Task.Delay(1000)) != connectTask)
                        throw new TimeoutException();

                    NetworkStream stream = client.GetStream();
                    byte[] sendBytes = Encoding.ASCII.GetBytes(message);
                    await stream.WriteAsync(sendBytes, 0, sendBytes.Length);

                    byte[] buffer = new byte[1024];
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                    string response = Encoding.ASCII.GetString(buffer, 0, bytesRead);

                    if (response.Contains(expected))
                        listBoxSuccess.Items.Add($"{ip}:{port} -> OK");
                    else
                        listBoxFail.Items.Add($"{ip}:{port} -> Neočekivan odgovor: {response}");
                }
            }
            catch (Exception ex)
            {
                listBoxFail.Items.Add($"{ip}:{port} -> TCP greška: {ex.Message}");
            }
        }

        private async Task TestUdp(IPAddress ip, int port, string message, string expected)
        {
            try
            {
                using (UdpClient client = new UdpClient())
                {
                    client.Client.SendTimeout = 500;
                    client.Client.ReceiveTimeout = 1000;

                    byte[] sendBytes = Encoding.ASCII.GetBytes(message);
                    await client.SendAsync(sendBytes, sendBytes.Length, ip.ToString(), port);

                    var receiveTask = client.ReceiveAsync();
                    if (await Task.WhenAny(receiveTask, Task.Delay(1000)) != receiveTask)
                        throw new TimeoutException();

                    string response = Encoding.ASCII.GetString(receiveTask.Result.Buffer);

                    if (response.Contains(expected))
                        listBoxSuccess.Items.Add($"{ip}:{port} -> OK");
                    else
                        listBoxFail.Items.Add($"{ip}:{port} -> Neočekivan odgovor: {response}");
                }
            }
            catch (Exception ex)
            {
                listBoxFail.Items.Add($"{ip}:{port} -> UDP greška: {ex.Message}");
            }
        }

    }
}
