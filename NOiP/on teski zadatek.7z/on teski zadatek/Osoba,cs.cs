﻿public class Osoba
{
	public string Ime { get; set; }
	public int Godine { get; set; }

	public Osoba(string ime, int godine)
	{
		Ime = ime;
		Godine = godine;
	}

	public virtual string PrikaziPodatke()
	{
		return $"Osoba: {Ime}, Godine: {Godine}";
	}
}
