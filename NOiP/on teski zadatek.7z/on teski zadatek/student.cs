﻿public class Student : Osoba
{
	public string Fakultet { get; set; }

	public Student(string ime, int godine, string fakultet)
		: base(ime, godine)
	{
		Fakultet = fakultet;
	}

	public override string PrikaziPodatke()
	{
		return $"Student: {Ime}, Godine: {Godine}, Fakultet: {Fakultet}";
	}
}
