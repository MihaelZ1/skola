﻿namespace WinFormsApp1
{
	partial class Form2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			txtIme = new TextBox();
			txtGodine = new TextBox();
			txtFakultet = new TextBox();
			btnPosalji = new Button();
			SuspendLayout();
			// 
			// txtIme
			// 
			txtIme.Location = new Point(38, 72);
			txtIme.Name = "txtIme";
			txtIme.Size = new Size(100, 23);
			txtIme.TabIndex = 0;
			// 
			// txtGodine
			// 
			txtGodine.Location = new Point(38, 117);
			txtGodine.Name = "txtGodine";
			txtGodine.Size = new Size(100, 23);
			txtGodine.TabIndex = 1;
			// 
			// txtFakultet
			// 
			txtFakultet.Location = new Point(38, 158);
			txtFakultet.Name = "txtFakultet";
			txtFakultet.Size = new Size(100, 23);
			txtFakultet.TabIndex = 2;
			// 
			// btnPosalji
			// 
			btnPosalji.Location = new Point(50, 197);
			btnPosalji.Name = "btnPosalji";
			btnPosalji.Size = new Size(75, 23);
			btnPosalji.TabIndex = 3;
			btnPosalji.Text = "button1";
			btnPosalji.UseVisualStyleBackColor = true;
			btnPosalji.Click += btnPosalji_Click;
			// 
			// Form2
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(800, 450);
			Controls.Add(btnPosalji);
			Controls.Add(txtFakultet);
			Controls.Add(txtGodine);
			Controls.Add(txtIme);
			Name = "Form2";
			Text = "Form2";
			Load += Form2_Load;
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private TextBox txtIme;
		private TextBox txtGodine;
		private TextBox txtFakultet;
		private Button btnPosalji;
	}
}