﻿namespace projekt
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button1 = new Button();
            button3 = new Button();
            contextMenuStrip1 = new ContextMenuStrip(components);
            prijavaToolStripMenuItem = new ToolStripMenuItem();
            txtPoruka = new TextBox();
            btnPrijenosPodataka = new Button();
            lblOdabranaDatoteka = new Label();
            lstDostupniKorisnici = new ListBox();
            contextMenuStrip2 = new ContextMenuStrip(components);
            urediToolStripMenuItem = new ToolStripMenuItem();
            btnPosalji = new Button();
            lstPrimljenePoruke = new TextBox();
            Feed = new Label();
            contextMenuStrip1.SuspendLayout();
            contextMenuStrip2.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(0, 0);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 0;
            button1.Text = "Prijava";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button3
            // 
            button3.Location = new Point(90, 0);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 1;
            button3.Text = "Uredi";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { prijavaToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(123, 28);
            // 
            // prijavaToolStripMenuItem
            // 
            prijavaToolStripMenuItem.Name = "prijavaToolStripMenuItem";
            prijavaToolStripMenuItem.Size = new Size(122, 24);
            prijavaToolStripMenuItem.Text = "Prijava";
            prijavaToolStripMenuItem.Click += prijavaToolStripMenuItem_Click;
            // 
            // txtPoruka
            // 
            txtPoruka.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtPoruka.BackColor = Color.Silver;
            txtPoruka.Location = new Point(41, 398);
            txtPoruka.Multiline = true;
            txtPoruka.Name = "txtPoruka";
            txtPoruka.Size = new Size(595, 47);
            txtPoruka.TabIndex = 3;
            // 
            // btnPrijenosPodataka
            // 
            btnPrijenosPodataka.BackColor = Color.Transparent;
            btnPrijenosPodataka.BackgroundImage = (Image)resources.GetObject("btnPrijenosPodataka.BackgroundImage");
            btnPrijenosPodataka.BackgroundImageLayout = ImageLayout.Zoom;
            btnPrijenosPodataka.Location = new Point(5, 397);
            btnPrijenosPodataka.Name = "btnPrijenosPodataka";
            btnPrijenosPodataka.Size = new Size(30, 49);
            btnPrijenosPodataka.TabIndex = 4;
            btnPrijenosPodataka.UseVisualStyleBackColor = false;
            btnPrijenosPodataka.Click += btnPrijenosPodataka_Click;
            // 
            // lblOdabranaDatoteka
            // 
            lblOdabranaDatoteka.AutoSize = true;
            lblOdabranaDatoteka.Location = new Point(62, 67);
            lblOdabranaDatoteka.Name = "lblOdabranaDatoteka";
            lblOdabranaDatoteka.Size = new Size(50, 20);
            lblOdabranaDatoteka.TabIndex = 6;
            lblOdabranaDatoteka.Text = "label1";
            // 
            // lstDostupniKorisnici
            // 
            lstDostupniKorisnici.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lstDostupniKorisnici.BackColor = Color.Black;
            lstDostupniKorisnici.BorderStyle = BorderStyle.None;
            lstDostupniKorisnici.ForeColor = Color.White;
            lstDostupniKorisnici.FormattingEnabled = true;
            lstDostupniKorisnici.Location = new Point(512, 90);
            lstDostupniKorisnici.Name = "lstDostupniKorisnici";
            lstDostupniKorisnici.Size = new Size(276, 100);
            lstDostupniKorisnici.TabIndex = 7;
            // 
            // contextMenuStrip2
            // 
            contextMenuStrip2.ImageScalingSize = new Size(20, 20);
            contextMenuStrip2.Items.AddRange(new ToolStripItem[] { urediToolStripMenuItem });
            contextMenuStrip2.Name = "contextMenuStrip2";
            contextMenuStrip2.Size = new Size(115, 28);
            // 
            // urediToolStripMenuItem
            // 
            urediToolStripMenuItem.Name = "urediToolStripMenuItem";
            urediToolStripMenuItem.Size = new Size(114, 24);
            urediToolStripMenuItem.Text = "Uredi";
            urediToolStripMenuItem.Click += urediToolStripMenuItem_Click;
            // 
            // btnPosalji
            // 
            btnPosalji.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnPosalji.BackColor = Color.Transparent;
            btnPosalji.Location = new Point(642, 398);
            btnPosalji.Name = "btnPosalji";
            btnPosalji.Size = new Size(152, 47);
            btnPosalji.TabIndex = 9;
            btnPosalji.Text = "Pošalji";
            btnPosalji.UseVisualStyleBackColor = false;
            btnPosalji.Click += btnPosalji_Click;
            // 
            // lstPrimljenePoruke
            // 
            lstPrimljenePoruke.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lstPrimljenePoruke.BackColor = Color.Black;
            lstPrimljenePoruke.ForeColor = Color.White;
            lstPrimljenePoruke.Location = new Point(5, 90);
            lstPrimljenePoruke.Multiline = true;
            lstPrimljenePoruke.Name = "lstPrimljenePoruke";
            lstPrimljenePoruke.ScrollBars = ScrollBars.Both;
            lstPrimljenePoruke.Size = new Size(501, 304);
            lstPrimljenePoruke.TabIndex = 10;
            // 
            // Feed
            // 
            Feed.AutoSize = true;
            Feed.ForeColor = Color.White;
            Feed.Location = new Point(5, 67);
            Feed.Name = "Feed";
            Feed.Size = new Size(39, 20);
            Feed.TabIndex = 11;
            Feed.Text = "Chat";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 0, 64);
            ClientSize = new Size(800, 450);
            Controls.Add(Feed);
            Controls.Add(lstPrimljenePoruke);
            Controls.Add(btnPosalji);
            Controls.Add(lstDostupniKorisnici);
            Controls.Add(lblOdabranaDatoteka);
            Controls.Add(btnPrijenosPodataka);
            Controls.Add(txtPoruka);
            Controls.Add(button3);
            Controls.Add(button1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Load += Form1_Load;
            contextMenuStrip1.ResumeLayout(false);
            contextMenuStrip2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button3;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem prijavaToolStripMenuItem;
        private TextBox txtPoruka;
        private Button btnPrijenosPodataka;
        private Label lblOdabranaDatoteka;
        private ListBox lstDostupniKorisnici;
        private ContextMenuStrip contextMenuStrip2;
        private ToolStripMenuItem urediToolStripMenuItem;
        private Button btnPosalji;
        private TextBox lstPrimljenePoruke;
        private Label Feed;
    }
}
