public Form1()
{
    InitializeComponent();

    // Pretpostavka: btnPosalji je kreiran u designeru
    btnPosalji.Enabled = false;  // inicijalno onemogu�en
    btnPosalji.Click += BtnPosalji_Click;
}

public void EnableControls()
{
    prijavljen = true;
    txtPoruka.Enabled = true;
    btnPrijenosPodataka.Enabled = true;
    btnPosalji.Enabled = true;  // omogu�i gumb po prijavi
}

private void BtnPosalji_Click(object sender, EventArgs e)
{
    if (!prijavljen)
    {
        MessageBox.Show("Morate se prijaviti prije slanja poruke.", "Gre�ka", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return;
    }

    if (lstDostupniKorisnici.SelectedItem == null)
    {
        MessageBox.Show("Molimo odaberite korisnika kojem �aljete poruku.", "Gre�ka", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return;
    }

    if (string.IsNullOrWhiteSpace(txtPoruka.Text))
    {
        MessageBox.Show("Poruka ne mo�e biti prazna.", "Gre�ka", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return;
    }

    string targetIP = lstDostupniKorisnici.SelectedItem.ToString();
    string poruka = txtPoruka.Text;

    try
    {
        using (TcpClient client = new TcpClient())
        {
            var connectResult = client.BeginConnect(targetIP, 9000, null, null);
            bool connected = connectResult.AsyncWaitHandle.WaitOne(TimeSpan.FromSeconds(2));
            if (!connected)
            {
                MessageBox.Show("Nije mogu�e uspostaviti vezu s korisnikom.", "Gre�ka", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            NetworkStream stream = client.GetStream();
            byte[] data = Encoding.UTF8.GetBytes(poruka);
            stream.Write(data, 0, data.Length);
            stream.Flush();

            MessageBox.Show("Poruka je uspje�no poslana.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show("Gre�ka prilikom slanja poruke: " + ex.Message, "Gre�ka", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
