﻿namespace glavnaForma
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            contextMenuStrip1 = new ContextMenuStrip(components);
            prijavToolStripMenuItem = new ToolStripMenuItem();
            txtPoruka = new TextBox();
            button1 = new Button();
            lstPrimljenePoruke = new ListBox();
            btnPrijenosPodataka = new Button();
            button3 = new Button();
            contextMenuStrip2 = new ContextMenuStrip(components);
            urediIPRangeToolStripMenuItem = new ToolStripMenuItem();
            lstDostupniKorisnici = new ListBox();
            lblOdabranaDatoteka = new Label();
            btnPosalji = new Button();
            contextMenuStrip1.SuspendLayout();
            contextMenuStrip2.SuspendLayout();
            SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { prijavToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(123, 28);
            contextMenuStrip1.Opening += contextMenuStrip1_Opening;
            // 
            // prijavToolStripMenuItem
            // 
            prijavToolStripMenuItem.Name = "prijavToolStripMenuItem";
            prijavToolStripMenuItem.Size = new Size(122, 24);
            prijavToolStripMenuItem.Text = "Prijava";
            prijavToolStripMenuItem.Click += prijavToolStripMenuItem_Click;
            // 
            // txtPoruka
            // 
            txtPoruka.Location = new Point(28, 106);
            txtPoruka.Name = "txtPoruka";
            txtPoruka.Size = new Size(164, 27);
            txtPoruka.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(-2, -2);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 2;
            button1.Text = "Home";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lstPrimljenePoruke
            // 
            lstPrimljenePoruke.FormattingEnabled = true;
            lstPrimljenePoruke.Location = new Point(28, 209);
            lstPrimljenePoruke.Name = "lstPrimljenePoruke";
            lstPrimljenePoruke.Size = new Size(163, 124);
            lstPrimljenePoruke.TabIndex = 3;
            // 
            // btnPrijenosPodataka
            // 
            btnPrijenosPodataka.Location = new Point(28, 156);
            btnPrijenosPodataka.Name = "btnPrijenosPodataka";
            btnPrijenosPodataka.Size = new Size(164, 29);
            btnPrijenosPodataka.TabIndex = 4;
            btnPrijenosPodataka.Text = "Odaberi datoteku";
            btnPrijenosPodataka.UseVisualStyleBackColor = true;
            btnPrijenosPodataka.Click += btnPrijenosPodataka_Click;
            // 
            // button3
            // 
            button3.Location = new Point(89, -2);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 5;
            button3.Text = "Uredi";
            button3.UseVisualStyleBackColor = true;
            // 
            // contextMenuStrip2
            // 
            contextMenuStrip2.ImageScalingSize = new Size(20, 20);
            contextMenuStrip2.Items.AddRange(new ToolStripItem[] { urediIPRangeToolStripMenuItem });
            contextMenuStrip2.Name = "contextMenuStrip2";
            contextMenuStrip2.Size = new Size(173, 28);
            // 
            // urediIPRangeToolStripMenuItem
            // 
            urediIPRangeToolStripMenuItem.Name = "urediIPRangeToolStripMenuItem";
            urediIPRangeToolStripMenuItem.Size = new Size(172, 24);
            urediIPRangeToolStripMenuItem.Text = "Uredi IP range";
            urediIPRangeToolStripMenuItem.Click += urediIPRangeToolStripMenuItem_Click;
            // 
            // lstDostupniKorisnici
            // 
            lstDostupniKorisnici.FormattingEnabled = true;
            lstDostupniKorisnici.Location = new Point(532, 106);
            lstDostupniKorisnici.Name = "lstDostupniKorisnici";
            lstDostupniKorisnici.Size = new Size(150, 104);
            lstDostupniKorisnici.TabIndex = 8;
            // 
            // lblOdabranaDatoteka
            // 
            lblOdabranaDatoteka.AutoSize = true;
            lblOdabranaDatoteka.Location = new Point(216, 164);
            lblOdabranaDatoteka.Name = "lblOdabranaDatoteka";
            lblOdabranaDatoteka.Size = new Size(50, 20);
            lblOdabranaDatoteka.TabIndex = 9;
            lblOdabranaDatoteka.Text = "label1";
            // 
            // btnPosalji
            // 
            btnPosalji.Location = new Point(216, 106);
            btnPosalji.Name = "btnPosalji";
            btnPosalji.Size = new Size(94, 29);
            btnPosalji.TabIndex = 10;
            btnPosalji.Text = "Pošalji";
            btnPosalji.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(btnPosalji);
            Controls.Add(lblOdabranaDatoteka);
            Controls.Add(lstDostupniKorisnici);
            Controls.Add(button3);
            Controls.Add(btnPrijenosPodataka);
            Controls.Add(lstPrimljenePoruke);
            Controls.Add(button1);
            Controls.Add(txtPoruka);
            ForeColor = SystemColors.ControlText;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            contextMenuStrip1.ResumeLayout(false);
            contextMenuStrip2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem prijavToolStripMenuItem;
        private TextBox txtPoruka;
        private Button button1;
        private ListBox lstPrimljenePoruke;
        private Button btnPrijenosPodataka;
        private Button button3;
        private ContextMenuStrip contextMenuStrip2;
        private ToolStripMenuItem urediIPRangeToolStripMenuItem;
        private ListBox lstDostupniKorisnici;
        private Label lblOdabranaDatoteka;
        private Button btnPosalji;
    }
}
