﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace glavnaForma
{
    public partial class Form2 : Form
    {
        private Form1 mainForm;  // polje za referencu na glavnu formu

        // Konstruktor prima referencu na Form1
        public Form2(Form1 form1)
        {
            InitializeComponent();
            this.mainForm = form1;
        }
      

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if ((username == "mihael" && password == "lozinka") ||
                (username == "admin" && password == "admin"))
            {
                MessageBox.Show("Prijava uspješna!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mainForm.EnableControls(); // otključaj kontrole na glavnoj formi
                this.Close(); // zatvori formu za prijavu
            }




            else
            {
                MessageBox.Show("Neispravno korisničko ime ili lozinka.", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
