﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	partial class FormKorisnici
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			this.dgvKorisnici = new System.Windows.Forms.DataGridView();
			this.dgvPrava = new System.Windows.Forms.DataGridView();
			this.btnDodajKorisnika = new System.Windows.Forms.Button();
			this.btnDodajPravo = new System.Windows.Forms.Button();
			this.btnObrisiPravo = new System.Windows.Forms.Button();
			this.btnOsvjezi = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dgvKorisnici)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgvPrava)).BeginInit();
			this.SuspendLayout();
			// 
			// dgvKorisnici
			// 
			this.dgvKorisnici.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvKorisnici.Location = new System.Drawing.Point(70, 66);
			this.dgvKorisnici.Name = "dgvKorisnici";
			this.dgvKorisnici.Size = new System.Drawing.Size(282, 150);
			this.dgvKorisnici.TabIndex = 0;
			this.dgvKorisnici.SelectionChanged += new System.EventHandler(this.dgvKorisnici_SelectionChanged);
			// 
			// dgvPrava
			// 
			this.dgvPrava.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvPrava.Location = new System.Drawing.Point(397, 66);
			this.dgvPrava.Name = "dgvPrava";
			this.dgvPrava.Size = new System.Drawing.Size(286, 150);
			this.dgvPrava.TabIndex = 1;
			// 
			// btnDodajKorisnika
			// 
			this.btnDodajKorisnika.Location = new System.Drawing.Point(70, 258);
			this.btnDodajKorisnika.Name = "btnDodajKorisnika";
			this.btnDodajKorisnika.Size = new System.Drawing.Size(125, 30);
			this.btnDodajKorisnika.TabIndex = 2;
			this.btnDodajKorisnika.Text = "Dodaj korisnika";
			this.btnDodajKorisnika.UseVisualStyleBackColor = true;
			this.btnDodajKorisnika.Click += new System.EventHandler(this.btnDodajKorisnika_Click);
			// 
			// btnDodajPravo
			// 
			this.btnDodajPravo.Location = new System.Drawing.Point(397, 258);
			this.btnDodajPravo.Name = "btnDodajPravo";
			this.btnDodajPravo.Size = new System.Drawing.Size(125, 30);
			this.btnDodajPravo.TabIndex = 3;
			this.btnDodajPravo.Text = "Dodaj pravo";
			this.btnDodajPravo.UseVisualStyleBackColor = true;
			this.btnDodajPravo.Click += new System.EventHandler(this.btnDodajPravo_Click);
			// 
			// btnObrisiPravo
			// 
			this.btnObrisiPravo.Location = new System.Drawing.Point(558, 258);
			this.btnObrisiPravo.Name = "btnObrisiPravo";
			this.btnObrisiPravo.Size = new System.Drawing.Size(125, 30);
			this.btnObrisiPravo.TabIndex = 4;
			this.btnObrisiPravo.Text = "Obriši pravo";
			this.btnObrisiPravo.UseVisualStyleBackColor = true;
			this.btnObrisiPravo.Click += new System.EventHandler(this.btnObrisiPravo_Click);
			// 
			// btnOsvjezi
			// 
			this.btnOsvjezi.Location = new System.Drawing.Point(336, 354);
			this.btnOsvjezi.Name = "btnOsvjezi";
			this.btnOsvjezi.Size = new System.Drawing.Size(125, 30);
			this.btnOsvjezi.TabIndex = 5;
			this.btnOsvjezi.Text = "Osvježi";
			this.btnOsvjezi.UseVisualStyleBackColor = true;
			this.btnOsvjezi.Click += new System.EventHandler(this.btnOsvjezi_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(67, 37);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(52, 15);
			this.label1.TabIndex = 6;
			this.label1.Text = "Korisnici:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(394, 37);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(92, 15);
			this.label2.TabIndex = 7;
			this.label2.Text = "Prava korisnika:";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(291, 415);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(170, 30);
			this.button1.TabIndex = 8;
			this.button1.Text = "Izlaz";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(227, 258);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(125, 30);
			this.button2.TabIndex = 9;
			this.button2.Text = "Izbriši korisnika";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// FormKorisnici
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnOsvjezi);
			this.Controls.Add(this.btnObrisiPravo);
			this.Controls.Add(this.btnDodajPravo);
			this.Controls.Add(this.btnDodajKorisnika);
			this.Controls.Add(this.dgvPrava);
			this.Controls.Add(this.dgvKorisnici);
			this.Name = "FormKorisnici";
			this.Text = "Korisnici i prava";
			this.Load += new System.EventHandler(this.FormKorisnici_Load);

			// ---------------------------------------------------------
			// MODERNI TAMNI GUI – AUTOMATSKI DODAN
			// ---------------------------------------------------------

			

			// ---------------------------------------------------------

			((System.ComponentModel.ISupportInitialize)(this.dgvKorisnici)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgvPrava)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		#endregion

		private System.Windows.Forms.DataGridView dgvKorisnici;
		private System.Windows.Forms.DataGridView dgvPrava;
		private System.Windows.Forms.Button btnDodajKorisnika;
		private System.Windows.Forms.Button btnDodajPravo;
		private System.Windows.Forms.Button btnObrisiPravo;
		private System.Windows.Forms.Button btnOsvjezi;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
	}
}
