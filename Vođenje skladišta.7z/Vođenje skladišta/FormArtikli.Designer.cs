﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	partial class FormArtikli
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			this.dgvArtikli = new System.Windows.Forms.DataGridView();
			this.button1 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dgvArtikli)).BeginInit();
			this.SuspendLayout();
			// 
			// dgvArtikli
			// 
			this.dgvArtikli.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvArtikli.Location = new System.Drawing.Point(45, 12);
			this.dgvArtikli.Name = "dgvArtikli";
			this.dgvArtikli.Size = new System.Drawing.Size(702, 360);
			this.dgvArtikli.TabIndex = 0;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(344, 401);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "Izlaz";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// FormArtikli
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.dgvArtikli);
			this.Name = "FormArtikli";
			this.Text = "Artikli";
			this.Load += new System.EventHandler(this.FormArtikli_Load);

			// ---------------------------------------------------------
			// MODERNI TAMNI GUI – AUTOMATSKI DODAN
			// ---------------------------------------------------------

			this.BackColor = Color.FromArgb(40, 40, 40);
			this.BackgroundImage = null;
			this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

			// Moderni DataGridView stil
			this.dgvArtikli.BackgroundColor = Color.FromArgb(55, 55, 55);
			this.dgvArtikli.BorderStyle = BorderStyle.None;
			this.dgvArtikli.EnableHeadersVisualStyles = false;

			this.dgvArtikli.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(70, 70, 70);
			this.dgvArtikli.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
			this.dgvArtikli.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);

			this.dgvArtikli.DefaultCellStyle.BackColor = Color.FromArgb(60, 60, 60);
			this.dgvArtikli.DefaultCellStyle.ForeColor = Color.White;
			this.dgvArtikli.DefaultCellStyle.SelectionBackColor = Color.FromArgb(90, 90, 90);
			this.dgvArtikli.DefaultCellStyle.SelectionForeColor = Color.White;

			this.dgvArtikli.GridColor = Color.FromArgb(80, 80, 80);

			// Moderni gumb
			this.button1.Size = new Size(120, 35);
			this.button1.Location = new Point(340, 390);
			this.button1.BackColor = Color.FromArgb(90, 40, 40);
			this.button1.ForeColor = Color.White;
			this.button1.FlatStyle = FlatStyle.Flat;
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);

			// ---------------------------------------------------------

			((System.ComponentModel.ISupportInitialize)(this.dgvArtikli)).EndInit();
			this.ResumeLayout(false);
		}

		#endregion

		private System.Windows.Forms.DataGridView dgvArtikli;
		private System.Windows.Forms.Button button1;
	}
}
