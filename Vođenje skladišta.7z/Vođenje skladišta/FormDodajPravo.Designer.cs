﻿namespace Vođenje_skladišta
{
	partial class FormDodajPravo
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmbPrava = new System.Windows.Forms.ComboBox();
			this.btnDodaj = new System.Windows.Forms.Button();
			this.btnOdustani = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// cmbPrava
			// 
			this.cmbPrava.FormattingEnabled = true;
			this.cmbPrava.Location = new System.Drawing.Point(25, 28);
			this.cmbPrava.Name = "cmbPrava";
			this.cmbPrava.Size = new System.Drawing.Size(121, 21);
			this.cmbPrava.TabIndex = 0;
			// 
			// btnDodaj
			// 
			this.btnDodaj.Location = new System.Drawing.Point(205, 66);
			this.btnDodaj.Name = "btnDodaj";
			this.btnDodaj.Size = new System.Drawing.Size(75, 23);
			this.btnDodaj.TabIndex = 1;
			this.btnDodaj.Text = "Dodaj";
			this.btnDodaj.UseVisualStyleBackColor = true;
			this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
			// 
			// btnOdustani
			// 
			this.btnOdustani.Location = new System.Drawing.Point(205, 95);
			this.btnOdustani.Name = "btnOdustani";
			this.btnOdustani.Size = new System.Drawing.Size(75, 23);
			this.btnOdustani.TabIndex = 2;
			this.btnOdustani.Text = "Odustani";
			this.btnOdustani.UseVisualStyleBackColor = true;
			this.btnOdustani.Click += new System.EventHandler(this.btnOdustani_Click);
			// 
			// FormDodajPravo
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(306, 146);
			this.Controls.Add(this.btnOdustani);
			this.Controls.Add(this.btnDodaj);
			this.Controls.Add(this.cmbPrava);
			this.Name = "FormDodajPravo";
			this.Text = "FormDodajPravo";
			this.Load += new System.EventHandler(this.FormDodajPravo_Load);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.ComboBox cmbPrava;
		private System.Windows.Forms.Button btnDodaj;
		private System.Windows.Forms.Button btnOdustani;
	}
}