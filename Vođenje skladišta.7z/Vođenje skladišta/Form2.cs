﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	public partial class Form2 : Form
	{
		private string prijavljeniKorisnik;
		public delegate void FormaOtvorenaHandler(string nazivForme);
		public event FormaOtvorenaHandler FormaOtvorena;
		public Form2(string username)
		{
			InitializeComponent();
			prijavljeniKorisnik = username;
		}

		private void Form2_Load(object sender, EventArgs e)
		{
			lblKorisnik.Text = $"Dobrodošli, {prijavljeniKorisnik}!";
			if (!JeAdmin(prijavljeniKorisnik))
				//lblKorisnik.Left = (panel1.Width - lblKorisnik.Width);
			{
				button4.Visible = false; // Pregled korisnika i prava
			}
			if (!JeProgramer(prijavljeniKorisnik))
			{
				button9.Visible = false;
			}
			this.BackColor = Color.FromArgb(40, 40, 40);
			this.BackgroundImage = null;
			this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
			this.Text = "Skladišni sustav";

			this.panel1.BackColor = Color.FromArgb(55, 55, 55);
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Size = new System.Drawing.Size(220, 450);

			Button[] sidebarButtons = { button1, button2, button3, button7, button8, button4 };

			int y = 20;
			foreach (var btn in sidebarButtons)
			{
				btn.Size = new Size(180, 35);
				btn.Location = new Point(20, y);
				btn.BackColor = Color.FromArgb(70, 70, 70);
				btn.ForeColor = Color.White;
				btn.FlatStyle = FlatStyle.Flat;
				btn.FlatAppearance.BorderSize = 0;
				btn.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
				y += 45;
			}

			this.lblKorisnik.ForeColor = Color.White;
			this.lblKorisnik.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
			this.lblKorisnik.Location = new Point(250, 20);

			this.button5.Size = new Size(100, 35);
			this.button6.Size = new Size(100, 35);

			this.button5.Location = new Point(250, 380);
			this.button6.Location = new Point(360, 380);

			this.button5.BackColor = Color.FromArgb(90, 40, 40);
			this.button6.BackColor = Color.FromArgb(40, 70, 120);

			this.button5.ForeColor = Color.White;
			this.button6.ForeColor = Color.White;

			this.button5.FlatStyle = FlatStyle.Flat;
			this.button6.FlatStyle = FlatStyle.Flat;

			this.button5.FlatAppearance.BorderSize = 0;
			this.button6.FlatAppearance.BorderSize = 0;

			this.button9.BackColor = Color.FromArgb(80, 80, 80);
			this.button9.ForeColor = Color.White;
			this.button9.FlatStyle = FlatStyle.Flat;
			this.button9.FlatAppearance.BorderSize = 0;
			this.button9.Font = new Font("Segoe UI", 9F, FontStyle.Bold);


		}

		private void button1_Click(object sender, EventArgs e)
		{
			FormArtikli f = new FormArtikli();
			f.ShowDialog();
			FormaOtvorena?.Invoke("FormArtikli");
		}

		private void button4_Click(object sender, EventArgs e)
		{
			FormKorisnici f = new FormKorisnici();
			f.ShowDialog();
			FormaOtvorena?.Invoke("FormKorisnici");
		}

		private void button2_Click(object sender, EventArgs e)
		{
			FormDodajArtikl f = new FormDodajArtikl();
			f.ShowDialog();
			FormaOtvorena?.Invoke("FormDodajArtikl");
		}

		private void button5_Click(object sender, EventArgs e)
		{
			DialogResult rezultat = MessageBox.Show(
	  "Želite li stvarno izaći iz programa?",
	  "Potvrda izlaza",
	  MessageBoxButtons.YesNo,
	  MessageBoxIcon.Question);

			if (rezultat == DialogResult.Yes)
			{
				Application.Exit();
			}
		}

		private void button6_Click(object sender, EventArgs e)
		{
			this.Hide();
			Form1 login = new Form1();
			login.Show();
		}

			private bool JeAdmin(string username)
			{
			string connectionString = ConnectionConfig.ConnectionString;


			using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();

					string query = @"
            SELECT COUNT(*) 
            FROM Korisnici k
            JOIN KorisniciPrava kp ON k.IdKorisnik = kp.IdKorisnik
            JOIN Prava p ON kp.IdPravo = p.IdPravo
            WHERE k.Username = @user AND p.NazivPrava = 'Admin'";

					SqlCommand cmd = new SqlCommand(query, conn);
					cmd.Parameters.AddWithValue("@user", username);

					int count = (int)cmd.ExecuteScalar();
					return count > 0;
				}
			}
		private bool JeProgramer(string username)
		{
			string connectionString = ConnectionConfig.ConnectionString;


			using (SqlConnection conn = new SqlConnection(connectionString))
			{
				conn.Open();

				string query = @"
            SELECT COUNT(*) 
            FROM Korisnici k
            JOIN KorisniciPrava kp ON k.IdKorisnik = kp.IdKorisnik
            JOIN Prava p ON kp.IdPravo = p.IdPravo
            WHERE k.Username = @user AND p.NazivPrava = 'Programer'";

				SqlCommand cmd = new SqlCommand(query, conn);
				cmd.Parameters.AddWithValue("@user", username);

				int count = (int)cmd.ExecuteScalar();
				return count > 0;
			}
		}


		private void button3_Click(object sender, EventArgs e)
		{
			FormNovaNarudzba f = new FormNovaNarudzba();
			f.ShowDialog();
			FormaOtvorena?.Invoke("FormNovaNarudzba");
		}

		private void button7_Click(object sender, EventArgs e)
		{
			FormPregledNarudzbi f = new FormPregledNarudzbi();
			f.ShowDialog();
			FormaOtvorena?.Invoke("FormPregledNarudzbi");
		}

		private void button8_Click(object sender, EventArgs e)
		{
			FormIzmjena f = new FormIzmjena();
			f.ShowDialog();
			FormaOtvorena?.Invoke("FormIzmjena");
		}

		private void button9_Click(object sender, EventArgs e)
		{
			FormProgramerska f = new FormProgramerska();
			f.ShowDialog();
			FormaOtvorena?.Invoke("FormProgramerska");
		}
	}
	}
	
