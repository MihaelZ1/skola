﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	public partial class FormIzmjena : Form
	{
		string connectionString = ConnectionConfig.ConnectionString;


		public FormIzmjena()
		{
			InitializeComponent();
		}

		private void FormIzmjena_Load(object sender, EventArgs e)
		{
			UcitajSveArtikle();
			txtId.ReadOnly = true;
			this.BackColor = Color.FromArgb(40, 40, 40);
			this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

			// TextBox stil
			TextBox[] inputs = { txtNaziv, txtOpis, txtCijena, txtKolicina, txtId };
			foreach (var t in inputs)
			{
				t.BackColor = Color.FromArgb(60, 60, 60);
				t.ForeColor = Color.White;
				t.BorderStyle = BorderStyle.FixedSingle;
			}

			// Label stil
			Label[] labels = { lblNaziv, lblOpis, lblCijena, label1, label2 };
			foreach (var l in labels)
			{
				l.ForeColor = Color.White;
				l.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
			}

			// Gumbi
			Button[] buttons = { btnSpremi, btnOdustani, btnIzlaz };
			foreach (var b in buttons)
			{
				b.FlatStyle = FlatStyle.Flat;
				b.FlatAppearance.BorderSize = 0;
				b.ForeColor = Color.White;
				b.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
				b.BackColor = Color.FromArgb(70, 70, 70);
			}

			btnSpremi.BackColor = Color.FromArgb(40, 120, 60);
			btnOdustani.BackColor = Color.FromArgb(120, 40, 40);
			btnIzlaz.BackColor = Color.FromArgb(90, 40, 40);

			// DataGridView stil
			this.dataGridView1.BackgroundColor = Color.FromArgb(55, 55, 55);
			this.dataGridView1.BorderStyle = BorderStyle.None;
			this.dataGridView1.EnableHeadersVisualStyles = false;

			this.dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(70, 70, 70);
			this.dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
			this.dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);

			this.dataGridView1.DefaultCellStyle.BackColor = Color.FromArgb(60, 60, 60);
			this.dataGridView1.DefaultCellStyle.ForeColor = Color.White;
			this.dataGridView1.DefaultCellStyle.SelectionBackColor = Color.FromArgb(90, 90, 90);
			this.dataGridView1.DefaultCellStyle.SelectionForeColor = Color.White;

			this.dataGridView1.GridColor = Color.FromArgb(80, 80, 80);

		}

		private void UcitajSveArtikle()
		{
			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();

					string query = "SELECT IdArtikl, Naziv, Opis, Kolicina, Cijena FROM Artikli";

					SqlDataAdapter da = new SqlDataAdapter(query, conn);
					DataTable dt = new DataTable();
					da.Fill(dt);

					dataGridView1.DataSource = dt;

					dataGridView1.Columns["IdArtikl"].HeaderText = "ID";
					dataGridView1.Columns["IdArtikl"].Width = 50;
					dataGridView1.Columns["Naziv"].Width = 150;
					dataGridView1.Columns["Opis"].Width = 200;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri učitavanju artikala: " + ex.Message);
			}
		}

		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0)
			{
				txtId.Text = dataGridView1.Rows[e.RowIndex].Cells["IdArtikl"].Value.ToString();
				txtNaziv.Text = dataGridView1.Rows[e.RowIndex].Cells["Naziv"].Value.ToString();
				txtOpis.Text = dataGridView1.Rows[e.RowIndex].Cells["Opis"].Value.ToString();
				txtKolicina.Text = dataGridView1.Rows[e.RowIndex].Cells["Kolicina"].Value.ToString();
				txtCijena.Text = dataGridView1.Rows[e.RowIndex].Cells["Cijena"].Value.ToString();
			}
		}

		private void btnSpremi_Click(object sender, EventArgs e)
		{
			if (!int.TryParse(txtId.Text, out int id))
			{
				MessageBox.Show("Odaberite artikl iz tablice!");
				return;
			}

			if (string.IsNullOrWhiteSpace(txtNaziv.Text))
			{
				MessageBox.Show("Naziv artikla je obavezan!");
				return;
			}

			if (!int.TryParse(txtKolicina.Text, out int kolicina) || kolicina < 0)
			{
				MessageBox.Show("Količina mora biti broj veći ili jednak 0!");
				return;
			}

			if (!decimal.TryParse(txtCijena.Text, out decimal cijena) || cijena < 0)
			{
				MessageBox.Show("Cijena mora biti broj veći ili jednak 0!");
				return;
			}

			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();

					string query = @"UPDATE Artikli 
                             SET Naziv = @Naziv, Opis = @Opis, Kolicina = @Kolicina, Cijena = @Cijena 
                             WHERE IdArtikl = @IdArtikl";

					using (SqlCommand cmd = new SqlCommand(query, conn))
					{
						cmd.Parameters.AddWithValue("@IdArtikl", id);
						cmd.Parameters.AddWithValue("@Naziv", txtNaziv.Text);
						cmd.Parameters.AddWithValue("@Opis", txtOpis.Text);
						cmd.Parameters.AddWithValue("@Kolicina", kolicina);
						cmd.Parameters.AddWithValue("@Cijena", cijena);

						cmd.ExecuteNonQuery();
					}
				}

				MessageBox.Show("Artikl uspješno ažuriran!");

				// 🔵 Osvježi DataGridView
				UcitajSveArtikle();

				// 🔵 Očisti polja
				txtId.Clear();
				txtNaziv.Clear();
				txtOpis.Clear();
				txtKolicina.Clear();
				txtCijena.Clear();

				// 🔵 Makni selekciju iz DataGridView-a
				dataGridView1.ClearSelection();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri spremanju izmjena: " + ex.Message);
			}
		}


		private void btnIzlaz_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void btnOdustani_Click(object sender, EventArgs e)
		{
			// Očisti sve textboxove
			txtId.Clear();
			txtNaziv.Clear();
			txtOpis.Clear();
			txtKolicina.Clear();
			txtCijena.Clear();

			// Makni selekciju iz DataGridView-a
			dataGridView1.ClearSelection();

			// Opcionalno: fokus vrati na DataGridView
			dataGridView1.Focus();
		}

	}
}
