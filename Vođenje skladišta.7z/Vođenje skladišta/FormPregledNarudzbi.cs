﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	public partial class FormPregledNarudzbi : Form
	{
		string connectionString = ConnectionConfig.ConnectionString;
		
		
		public FormPregledNarudzbi()
		{
			InitializeComponent();
		}

		private void btnOsvjezi_Click(object sender, EventArgs e)
		{
			UcitajNarudzbe();
			dgvStavke.DataSource = null;
		}

		private void FormPregledNarudzbi_Load(object sender, EventArgs e)
		{
			UcitajNarudzbe();
			this.BackColor = Color.FromArgb(40, 40, 40);
			this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

			// DataGridView stil
			DataGridView[] grids = { dgvNarudzbe, dgvStavke };
			foreach (var g in grids)
			{
				g.BackgroundColor = Color.FromArgb(55, 55, 55);
				g.BorderStyle = BorderStyle.None;
				g.EnableHeadersVisualStyles = false;

				g.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(70, 70, 70);
				g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
				g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);

				g.DefaultCellStyle.BackColor = Color.FromArgb(60, 60, 60);
				g.DefaultCellStyle.ForeColor = Color.White;
				g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(90, 90, 90);
				g.DefaultCellStyle.SelectionForeColor = Color.White;

				g.GridColor = Color.FromArgb(80, 80, 80);
			}

			// Gumbi
			Button[] buttons = { btnOsvjezi, button1 };
			foreach (var b in buttons)
			{
				b.FlatStyle = FlatStyle.Flat;
				b.FlatAppearance.BorderSize = 0;
				b.ForeColor = Color.White;
				b.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
				b.BackColor = Color.FromArgb(70, 70, 70);
			}

			btnOsvjezi.BackColor = Color.FromArgb(40, 120, 60);
			button1.BackColor = Color.FromArgb(120, 40, 40);
		}
		private void UcitajNarudzbe()
		{
			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();

					string query = "SELECT IdNarudzba, Ime, Datum, Ukupno FROM Narudzbe ORDER BY Datum DESC";

					SqlDataAdapter da = new SqlDataAdapter(query, conn);
					DataTable dt = new DataTable();
					da.Fill(dt);

					dgvNarudzbe.DataSource = dt;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri učitavanju narudžbi: " + ex.Message);
			}
		}
		private void dgvNarudzbe_SelectionChanged(object sender, EventArgs e)
		{
			if (dgvNarudzbe.SelectedRows.Count > 0)
			{
				int idNarudzba = Convert.ToInt32(dgvNarudzbe.SelectedRows[0].Cells["IdNarudzba"].Value);
				UcitajStavke(idNarudzba);
			}
		}

		private void UcitajStavke(int idNarudzba)
		{
			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();

					string query = @"
                        SELECT 
                            s.IdStavka,
                            a.Naziv AS Artikl,
                            s.Cijena,
                            s.Kolicina,
                            s.Ukupno

                        FROM NarudzbaStavke s
                        JOIN Artikli a ON s.IdArtikl = a.IdArtikl
                        WHERE s.IdNarudzba = @id";

					SqlDataAdapter da = new SqlDataAdapter(query, conn);
					da.SelectCommand.Parameters.AddWithValue("@id", idNarudzba);

					DataTable dt = new DataTable();
					da.Fill(dt);

					dgvStavke.DataSource = dt;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri učitavanju stavki: " + ex.Message);
			}
		}

		private void dgvNarudzbe_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
