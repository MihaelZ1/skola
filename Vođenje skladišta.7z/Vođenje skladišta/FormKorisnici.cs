﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	public partial class FormKorisnici : Form
	{
		string connectionString = ConnectionConfig.ConnectionString;
		public FormKorisnici()
		{
			InitializeComponent();
		}

		private void FormKorisnici_Load(object sender, EventArgs e)
		{
			UcitajKorisnike();
			UcitajPrava();
			this.BackColor = Color.FromArgb(40, 40, 40);
			this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

			// DataGridView stil
			DataGridView[] grids = { dgvKorisnici, dgvPrava };
			foreach (var g in grids)
			{
				g.BackgroundColor = Color.FromArgb(55, 55, 55);
				g.BorderStyle = BorderStyle.None;
				g.EnableHeadersVisualStyles = false;

				g.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(70, 70, 70);
				g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
				g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);

				g.DefaultCellStyle.BackColor = Color.FromArgb(60, 60, 60);
				g.DefaultCellStyle.ForeColor = Color.White;
				g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(90, 90, 90);
				g.DefaultCellStyle.SelectionForeColor = Color.White;

				g.GridColor = Color.FromArgb(80, 80, 80);
			}

			// Label stil
			Label[] labels = { label1, label2 };
			foreach (var l in labels)
			{
				l.ForeColor = Color.White;
				l.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
			}

			// Gumbi
			Button[] buttons = { btnDodajKorisnika, btnDodajPravo, btnObrisiPravo, btnOsvjezi, button1, button2 };
			foreach (var b in buttons)
			{
				b.FlatStyle = FlatStyle.Flat;
				b.FlatAppearance.BorderSize = 0;
				b.ForeColor = Color.White;
				b.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
				b.BackColor = Color.FromArgb(70, 70, 70);
			}

			btnDodajKorisnika.BackColor = Color.FromArgb(40, 120, 60);
			btnDodajPravo.BackColor = Color.FromArgb(40, 120, 60);
			btnObrisiPravo.BackColor = Color.FromArgb(120, 40, 40);
			button2.BackColor = Color.FromArgb(120, 40, 40);
			button1.BackColor = Color.FromArgb(90, 40, 40);
		}
		private void UcitajKorisnike()
		{
			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();
					string query = @"SELECT IdKorisnik, Username FROM Korisnici 
                             WHERE Username NOT IN ('Admin', 'Programer')";

					SqlDataAdapter da = new SqlDataAdapter(query, conn);
					DataTable dt = new DataTable();
					da.Fill(dt);

					dgvKorisnici.DataSource = dt;

					// Ako ima redova, prisilno selektiraj prvi red
					if (dgvKorisnici.Rows.Count > 0)
					{
						dgvKorisnici.CurrentCell = dgvKorisnici.Rows[0].Cells["Username"];
						dgvKorisnici.Rows[0].Selected = true;
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri učitavanju korisnika: " + ex.Message);
			}
		}


		private void dgvKorisnici_SelectionChanged(object sender, EventArgs e)
		{
			// Provjeravamo ima li selektiranih redova
			if (dgvKorisnici.SelectedRows.Count > 0)
			{
				// Uzimamo IdKorisnik iz prvog selektiranog reda
				var cellValue = dgvKorisnici.SelectedRows[0].Cells["IdKorisnik"].Value;

				if (cellValue != null && cellValue != DBNull.Value)
				{
					int idKorisnik = Convert.ToInt32(cellValue);
					UcitajPrava();
				}
			}
		}
		private void UcitajPrava()
		{
			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();
					// Dodajemo ID-ove kako bi brisanje radilo, ali ćemo ih sakriti u Gridu
					string query = @"
                SELECT kp.IdKorisnik, kp.IdPravo, k.Username, p.NazivPrava
                FROM KorisniciPrava kp
                JOIN Korisnici k ON kp.IdKorisnik = k.IdKorisnik
                JOIN Prava p ON kp.IdPravo = p.IdPravo
                WHERE k.Username NOT IN ('Admin', 'Programer')
                ORDER BY k.Username";

					SqlDataAdapter da = new SqlDataAdapter(query, conn);
					DataTable dt = new DataTable();
					da.Fill(dt);

					dgvPrava.DataSource = dt;

					// Sakrivamo ID stupce da korisnik vidi samo imena
					if (dgvPrava.Columns.Contains("IdKorisnik")) dgvPrava.Columns["IdKorisnik"].Visible = false;
					if (dgvPrava.Columns.Contains("IdPravo")) dgvPrava.Columns["IdPravo"].Visible = false;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri učitavanju liste prava: " + ex.Message);
			}
		}


		private void dgvKorisnici_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			if (dgvKorisnici.SelectedRows.Count > 0)
			{
				int idKorisnik = Convert.ToInt32(dgvKorisnici.SelectedRows[0].Cells["IdKorisnik"].Value);
				UcitajPrava();
			}
		}

		private void btnDodajKorisnika_Click(object sender, EventArgs e)
		{
			FormDodajKorisnika f = new FormDodajKorisnika();
			f.ShowDialog();
			UcitajKorisnike();
		}

		private void btnDodajPravo_Click(object sender, EventArgs e)
		{
			// Provjera je li korisnik uopće odabran u gornjoj tablici
			if (dgvKorisnici.CurrentRow == null)
			{
				MessageBox.Show("Molimo odaberite korisnika u gornjoj tablici kojem želite dodati pravo.");
				return;
			}

			// Izvlačenje ID-a selektiranog korisnika
			int idKorisnik = Convert.ToInt32(dgvKorisnici.CurrentRow.Cells["IdKorisnik"].Value);

			// Otvaranje forme za dodavanje i slanje ID-a
			FormDodajPravo f = new FormDodajPravo(idKorisnik);
			f.ShowDialog();

			// Ključno: Osvježavanje donje tablice nakon što se prozor zatvori
			UcitajPrava();
		}

		private void btnObrisiPravo_Click(object sender, EventArgs e)
		{
			if (dgvPrava.SelectedRows.Count == 0)
			{
				MessageBox.Show("Odaberite red u tablici prava koji želite obrisati.");
				return;
			}

			int idKorisnik = Convert.ToInt32(dgvPrava.SelectedRows[0].Cells["IdKorisnik"].Value);
			int idPravo = Convert.ToInt32(dgvPrava.SelectedRows[0].Cells["IdPravo"].Value);

			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();
					string query = "DELETE FROM KorisniciPrava WHERE IdKorisnik=@k AND IdPravo=@p";
					SqlCommand cmd = new SqlCommand(query, conn);
					cmd.Parameters.AddWithValue("@k", idKorisnik);
					cmd.Parameters.AddWithValue("@p", idPravo);
					cmd.ExecuteNonQuery();
				}
				MessageBox.Show("Pravo uklonjeno.");
				UcitajPrava();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri brisanju: " + ex.Message);
			}
		}

		private void btnOsvjezi_Click(object sender, EventArgs e)
		{
			UcitajKorisnike();
			UcitajPrava();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			if (dgvKorisnici.SelectedRows.Count == 0)
			{
				MessageBox.Show("Odaberite korisnika kojeg želite izbrisati.");
				return;
			}

			int idKorisnik = Convert.ToInt32(dgvKorisnici.SelectedRows[0].Cells["IdKorisnik"].Value);
			string username = dgvKorisnici.SelectedRows[0].Cells["Username"].Value.ToString();

			// Potvrda
			DialogResult r = MessageBox.Show(
				$"Jeste li sigurni da želite izbrisati korisnika '{username}'?",
				"Potvrda brisanja",
				MessageBoxButtons.YesNo,
				MessageBoxIcon.Warning);

			if (r != DialogResult.Yes)
				return;

			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();

					// 1. Prvo obriši prava korisnika (FK constraint)
					string deletePrava = "DELETE FROM KorisniciPrava WHERE IdKorisnik=@id";
					SqlCommand cmd1 = new SqlCommand(deletePrava, conn);
					cmd1.Parameters.AddWithValue("@id", idKorisnik);
					cmd1.ExecuteNonQuery();

					// 2. Obriši korisnika
					string deleteKorisnik = "DELETE FROM Korisnici WHERE IdKorisnik=@id";
					SqlCommand cmd2 = new SqlCommand(deleteKorisnik, conn);
					cmd2.Parameters.AddWithValue("@id", idKorisnik);
					cmd2.ExecuteNonQuery();
				}

				MessageBox.Show("Korisnik uspješno izbrisan.");
				UcitajKorisnike(); // osvježi listu
				dgvPrava.DataSource = null; // očisti prikaz prava
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri brisanju korisnika: " + ex.Message);
			}
		}
	}
}
