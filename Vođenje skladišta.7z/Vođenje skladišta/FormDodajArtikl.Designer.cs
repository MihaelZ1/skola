﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	partial class FormDodajArtikl
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			this.txtNaziv = new System.Windows.Forms.TextBox();
			this.txtOpis = new System.Windows.Forms.TextBox();
			this.txtKolicina = new System.Windows.Forms.TextBox();
			this.txtCijena = new System.Windows.Forms.TextBox();
			this.btnSpremi = new System.Windows.Forms.Button();
			this.btnOdustani = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtNaziv
			// 
			this.txtNaziv.Location = new System.Drawing.Point(140, 80);
			this.txtNaziv.Name = "txtNaziv";
			this.txtNaziv.Size = new System.Drawing.Size(180, 23);
			this.txtNaziv.TabIndex = 0;
			// 
			// txtOpis
			// 
			this.txtOpis.Location = new System.Drawing.Point(140, 120);
			this.txtOpis.Name = "txtOpis";
			this.txtOpis.Size = new System.Drawing.Size(180, 23);
			this.txtOpis.TabIndex = 1;
			// 
			// txtKolicina
			// 
			this.txtKolicina.Location = new System.Drawing.Point(140, 160);
			this.txtKolicina.Name = "txtKolicina";
			this.txtKolicina.Size = new System.Drawing.Size(180, 23);
			this.txtKolicina.TabIndex = 2;
			// 
			// txtCijena
			// 
			this.txtCijena.Location = new System.Drawing.Point(140, 200);
			this.txtCijena.Name = "txtCijena";
			this.txtCijena.Size = new System.Drawing.Size(180, 23);
			this.txtCijena.TabIndex = 3;
			// 
			// btnSpremi
			// 
			this.btnSpremi.Location = new System.Drawing.Point(400, 120);
			this.btnSpremi.Name = "btnSpremi";
			this.btnSpremi.Size = new System.Drawing.Size(120, 35);
			this.btnSpremi.TabIndex = 4;
			this.btnSpremi.Text = "Spremi";
			this.btnSpremi.UseVisualStyleBackColor = true;
			this.btnSpremi.Click += new System.EventHandler(this.btnSpremi_Click);
			// 
			// btnOdustani
			// 
			this.btnOdustani.Location = new System.Drawing.Point(400, 170);
			this.btnOdustani.Name = "btnOdustani";
			this.btnOdustani.Size = new System.Drawing.Size(120, 35);
			this.btnOdustani.TabIndex = 5;
			this.btnOdustani.Text = "Izlaz";
			this.btnOdustani.UseVisualStyleBackColor = true;
			this.btnOdustani.Click += new System.EventHandler(this.btnOdustani_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(80, 83);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(42, 15);
			this.label1.TabIndex = 6;
			this.label1.Text = "Naziv:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(80, 123);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(36, 15);
			this.label2.TabIndex = 7;
			this.label2.Text = "Opis:";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(70, 163);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(54, 15);
			this.label3.TabIndex = 8;
			this.label3.Text = "Količina:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(80, 203);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(45, 15);
			this.label4.TabIndex = 9;
			this.label4.Text = "Cijena:";
			// 
			// FormDodajArtikl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(650, 350);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnOdustani);
			this.Controls.Add(this.btnSpremi);
			this.Controls.Add(this.txtCijena);
			this.Controls.Add(this.txtKolicina);
			this.Controls.Add(this.txtOpis);
			this.Controls.Add(this.txtNaziv);
			this.Name = "FormDodajArtikl";
			this.Text = "Dodavanje artikla";
			this.Load += new System.EventHandler(this.FormDodajArtikl_Load);

			// ---------------------------------------------------------
			// MODERNI TAMNI GUI – AUTOMATSKI DODAN
			// ---------------------------------------------------------


			// ---------------------------------------------------------

			this.ResumeLayout(false);
			this.PerformLayout();
		}

		#endregion

		private System.Windows.Forms.TextBox txtNaziv;
		private System.Windows.Forms.TextBox txtOpis;
		private System.Windows.Forms.TextBox txtKolicina;
		private System.Windows.Forms.TextBox txtCijena;
		private System.Windows.Forms.Button btnSpremi;
		private System.Windows.Forms.Button btnOdustani;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
	}
}
