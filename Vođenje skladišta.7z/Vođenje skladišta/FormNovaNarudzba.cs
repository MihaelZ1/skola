﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	public partial class FormNovaNarudzba : Form
	{
		string connectionString = ConnectionConfig.ConnectionString;
		private DataTable stavkeNarudzbe = new DataTable();
		public FormNovaNarudzba()
		{
			InitializeComponent();
		}

		private void FormNovaNarudzba_Load(object sender, EventArgs e)
		{
			UcitajArtikle();
			UcitajKolicine();
			PripremiTablicuStavki();

			this.BackColor = Color.FromArgb(40, 40, 40);
			this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

			// ComboBox stil
			ComboBox[] combos = { cmbArtikl, cmbKolicina };
			foreach (var c in combos)
			{
				c.BackColor = Color.FromArgb(60, 60, 60);
				c.ForeColor = Color.White;
				c.FlatStyle = FlatStyle.Flat;
			}

			// TextBox stil
			TextBox[] inputs = { txtCijena, txtUkupno, tb_ime };
			foreach (var t in inputs)
			{
				t.BackColor = Color.FromArgb(60, 60, 60);
				t.ForeColor = Color.White;
				t.BorderStyle = BorderStyle.FixedSingle;
			}

			// Label stil
			Label[] labels = { label1, label2, label3, Količina, label4 };
			foreach (var l in labels)
			{
				l.ForeColor = Color.White;
				l.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
			}

			// Gumbi
			Button[] buttons = { btnSpremiNarudzbu, btnOdustani, btnDodajStavku };
			foreach (var b in buttons)
			{
				b.FlatStyle = FlatStyle.Flat;
				b.FlatAppearance.BorderSize = 0;
				b.ForeColor = Color.White;
				b.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
				b.BackColor = Color.FromArgb(70, 70, 70);
			}

			btnSpremiNarudzbu.BackColor = Color.FromArgb(40, 120, 60);
			btnOdustani.BackColor = Color.FromArgb(120, 40, 40);
			btnDodajStavku.BackColor = Color.FromArgb(40, 70, 120);

			// DataGridView stil
			this.dgvStavke.BackgroundColor = Color.FromArgb(55, 55, 55);
			this.dgvStavke.BorderStyle = BorderStyle.None;
			this.dgvStavke.EnableHeadersVisualStyles = false;

			this.dgvStavke.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(70, 70, 70);
			this.dgvStavke.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
			this.dgvStavke.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);

			this.dgvStavke.DefaultCellStyle.BackColor = Color.FromArgb(60, 60, 60);
			this.dgvStavke.DefaultCellStyle.ForeColor = Color.White;
			this.dgvStavke.DefaultCellStyle.SelectionBackColor = Color.FromArgb(90, 90, 90);
			this.dgvStavke.DefaultCellStyle.SelectionForeColor = Color.White;

			this.dgvStavke.GridColor = Color.FromArgb(80, 80, 80);
		}
		private void UcitajArtikle()
		{
			using (SqlConnection conn = new SqlConnection(connectionString))
			{
				conn.Open();
				SqlDataAdapter da = new SqlDataAdapter("SELECT IdArtikl, Naziv, Cijena FROM Artikli", conn);
				DataTable dt = new DataTable();
				da.Fill(dt);

				cmbArtikl.DataSource = dt;
				cmbArtikl.DisplayMember = "Naziv";
				cmbArtikl.ValueMember = "IdArtikl";
			}
		}

		private void UcitajKolicine()
		{
			for (int i = 1; i <= 15; i++)
				cmbKolicina.Items.Add(i);

			cmbKolicina.SelectedIndex = 0;
		}

		private void PripremiTablicuStavki()
		{
			stavkeNarudzbe.Columns.Add("IdArtikl", typeof(int));
			stavkeNarudzbe.Columns.Add("Naziv", typeof(string));
			stavkeNarudzbe.Columns.Add("Cijena", typeof(decimal));
			stavkeNarudzbe.Columns.Add("Kolicina", typeof(int));
			stavkeNarudzbe.Columns.Add("Ukupno", typeof(decimal));

			dgvStavke.DataSource = stavkeNarudzbe;
		}

		private void cmbArtikl_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (cmbArtikl.SelectedItem is DataRowView row)
			{
				txtCijena.Text = row["Cijena"].ToString();
			}
		}

		private void btnDodajStavku_Click(object sender, EventArgs e)
		{
			if (cmbArtikl.SelectedItem is DataRowView row)
			{
				int idArtikl = Convert.ToInt32(row["IdArtikl"]);
				string naziv = row["Naziv"].ToString();
				decimal cijena = Convert.ToDecimal(row["Cijena"]);
				int kolicina = Convert.ToInt32(cmbKolicina.Text);
				decimal ukupno = cijena * kolicina;

				stavkeNarudzbe.Rows.Add(idArtikl, naziv, cijena, kolicina, ukupno);

				IzracunajUkupnoNarudzbe();
			}
		}
		private void IzracunajUkupnoNarudzbe()
		{
			decimal suma = 0;

			foreach (DataRow r in stavkeNarudzbe.Rows)
				suma += Convert.ToDecimal(r["Ukupno"]);

			txtUkupno.Text = suma.ToString("0.00");
		}

		private void btnSpremiNarudzbu_Click(object sender, EventArgs e)
		{
			if (stavkeNarudzbe.Rows.Count == 0)
			{
				MessageBox.Show("Narudžba je prazna.");
				return;
			}

			decimal ukupnoNarudzba = Convert.ToDecimal(txtUkupno.Text);
			int idNarudzba;

			using (SqlConnection conn = new SqlConnection(connectionString))
			{
				conn.Open();
				if (string.IsNullOrWhiteSpace(tb_ime.Text))
				{
					MessageBox.Show("Unesite ime narudžbe.");
					return;
				}


				// 1. Spremi narudžbu
				string queryNarudzba = "INSERT INTO Narudzbe (Ukupno, Ime) OUTPUT INSERTED.IdNarudzba VALUES (@u, @ime)";
				SqlCommand cmd = new SqlCommand(queryNarudzba, conn);
				cmd.Parameters.AddWithValue("@u", ukupnoNarudzba);
				cmd.Parameters.AddWithValue("@ime", tb_ime.Text);


				idNarudzba = (int)cmd.ExecuteScalar();

				// 2. Spremi stavke
				foreach (DataRow r in stavkeNarudzbe.Rows)
				{
					string queryStavka = @"
                        INSERT INTO NarudzbaStavke (IdNarudzba, IdArtikl, Kolicina, Cijena, Ukupno)
                        VALUES (@n, @a, @k, @c, @u)";

					SqlCommand cmd2 = new SqlCommand(queryStavka, conn);
					cmd2.Parameters.AddWithValue("@n", idNarudzba);
					cmd2.Parameters.AddWithValue("@a", r["IdArtikl"]);
					cmd2.Parameters.AddWithValue("@k", r["Kolicina"]);
					cmd2.Parameters.AddWithValue("@c", r["Cijena"]);
					cmd2.Parameters.AddWithValue("@u", r["Ukupno"]);

					cmd2.ExecuteNonQuery();
				}
			}

			MessageBox.Show("Narudžba uspješno spremljena!");
			this.Close();
		}

		private void btnOdustani_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
