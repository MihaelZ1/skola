﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	public partial class FormDodajArtikl : Form
	{
		string connectionString = ConnectionConfig.ConnectionString;

		public FormDodajArtikl()
		{
			InitializeComponent();
		}

		private void FormDodajArtikl_Load(object sender, EventArgs e)
		{

			this.BackColor = Color.FromArgb(40, 40, 40);
			this.BackgroundImage = null;
			this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

			// TextBox stil
			TextBox[] inputs = { txtNaziv, txtOpis, txtKolicina, txtCijena };
			foreach (var t in inputs)
			{
				t.BackColor = Color.FromArgb(60, 60, 60);
				t.ForeColor = Color.White;
				t.BorderStyle = BorderStyle.FixedSingle;
			}

			// Label stil
			Label[] labels = { label1, label2, label3, label4 };
			foreach (var l in labels)
			{
				l.ForeColor = Color.White;
				l.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
			}

			// Gumbi
			Button[] buttons = { btnSpremi, btnOdustani };
			foreach (var b in buttons)
			{
				b.FlatStyle = FlatStyle.Flat;
				b.FlatAppearance.BorderSize = 0;
				b.ForeColor = Color.White;
				b.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
				b.BackColor = Color.FromArgb(70, 70, 70);
			}

			btnSpremi.BackColor = Color.FromArgb(40, 120, 60);
			btnOdustani.BackColor = Color.FromArgb(120, 40, 40);
		}

		private void btnSpremi_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrWhiteSpace(txtNaziv.Text))
			{
				MessageBox.Show("Naziv artikla je obavezan!");
				return;
			}

			if (!int.TryParse(txtKolicina.Text, out int kolicina) || kolicina < 0)
			{
				MessageBox.Show("Količina mora biti broj veći ili jednak 0!");
				return;
			}

			if (!decimal.TryParse(txtCijena.Text, out decimal cijena) || cijena < 0)
			{
				MessageBox.Show("Cijena mora biti broj veći ili jednak 0!");
				return;
			}

			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();

					string query = @"INSERT INTO Artikli (Naziv, Opis, Kolicina, Cijena)
                                     VALUES (@Naziv, @Opis, @Kolicina, @Cijena)";

					using (SqlCommand cmd = new SqlCommand(query, conn))
					{
						cmd.Parameters.AddWithValue("@Naziv", txtNaziv.Text);
						cmd.Parameters.AddWithValue("@Opis", txtOpis.Text);
						cmd.Parameters.AddWithValue("@Kolicina", kolicina);
						cmd.Parameters.AddWithValue("@Cijena", cijena);

						cmd.ExecuteNonQuery();
					}
				}

				MessageBox.Show("Artikl uspješno dodan!");

				// Očisti polja
				txtNaziv.Clear();
				txtOpis.Clear();
				txtKolicina.Clear();
				txtCijena.Clear();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri dodavanju artikla: " + ex.Message);
			}
		}

		private void btnOdustani_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
