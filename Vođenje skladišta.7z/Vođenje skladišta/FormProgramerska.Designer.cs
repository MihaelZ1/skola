﻿namespace Vođenje_skladišta
{
	partial class FormProgramerska
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtServer = new System.Windows.Forms.TextBox();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.txtUser = new System.Windows.Forms.TextBox();
			this.txtDatabase = new System.Windows.Forms.TextBox();
			this.chkEncrypt = new System.Windows.Forms.CheckBox();
			this.chkTrust = new System.Windows.Forms.CheckBox();
			this.chkIntegrated = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.L = new System.Windows.Forms.Label();
			this.btnSpremi = new System.Windows.Forms.Button();
			this.btnTest = new System.Windows.Forms.Button();
			this.btnOdustani = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtServer
			// 
			this.txtServer.Location = new System.Drawing.Point(12, 25);
			this.txtServer.Name = "txtServer";
			this.txtServer.Size = new System.Drawing.Size(286, 20);
			this.txtServer.TabIndex = 0;
			// 
			// txtPassword
			// 
			this.txtPassword.Location = new System.Drawing.Point(12, 149);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.Size = new System.Drawing.Size(126, 20);
			this.txtPassword.TabIndex = 2;
			// 
			// txtUser
			// 
			this.txtUser.Location = new System.Drawing.Point(12, 106);
			this.txtUser.Name = "txtUser";
			this.txtUser.Size = new System.Drawing.Size(126, 20);
			this.txtUser.TabIndex = 2;
			// 
			// txtDatabase
			// 
			this.txtDatabase.Location = new System.Drawing.Point(12, 67);
			this.txtDatabase.Name = "txtDatabase";
			this.txtDatabase.Size = new System.Drawing.Size(126, 20);
			this.txtDatabase.TabIndex = 2;
			// 
			// chkEncrypt
			// 
			this.chkEncrypt.AutoSize = true;
			this.chkEncrypt.Location = new System.Drawing.Point(170, 64);
			this.chkEncrypt.Name = "chkEncrypt";
			this.chkEncrypt.Size = new System.Drawing.Size(62, 17);
			this.chkEncrypt.TabIndex = 3;
			this.chkEncrypt.Text = "Encrypt";
			this.chkEncrypt.UseVisualStyleBackColor = true;
			// 
			// chkTrust
			// 
			this.chkTrust.AutoSize = true;
			this.chkTrust.Location = new System.Drawing.Point(170, 90);
			this.chkTrust.Name = "chkTrust";
			this.chkTrust.Size = new System.Drawing.Size(128, 17);
			this.chkTrust.TabIndex = 4;
			this.chkTrust.Text = "TrustServerCertificate";
			this.chkTrust.UseVisualStyleBackColor = true;
			// 
			// chkIntegrated
			// 
			this.chkIntegrated.AutoSize = true;
			this.chkIntegrated.Location = new System.Drawing.Point(170, 114);
			this.chkIntegrated.Name = "chkIntegrated";
			this.chkIntegrated.Size = new System.Drawing.Size(115, 17);
			this.chkIntegrated.TabIndex = 5;
			this.chkIntegrated.Text = "Integrated Security";
			this.chkIntegrated.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 10);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(90, 13);
			this.label1.TabIndex = 7;
			this.label1.Text = "Server / Instance";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(53, 13);
			this.label2.TabIndex = 8;
			this.label2.Text = "Database";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(12, 90);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(43, 13);
			this.label3.TabIndex = 9;
			this.label3.Text = "User ID";
			// 
			// L
			// 
			this.L.AutoSize = true;
			this.L.Location = new System.Drawing.Point(12, 133);
			this.L.Name = "L";
			this.L.Size = new System.Drawing.Size(53, 13);
			this.L.TabIndex = 10;
			this.L.Text = "Password";
			// 
			// btnSpremi
			// 
			this.btnSpremi.Location = new System.Drawing.Point(181, 146);
			this.btnSpremi.Name = "btnSpremi";
			this.btnSpremi.Size = new System.Drawing.Size(75, 23);
			this.btnSpremi.TabIndex = 11;
			this.btnSpremi.Text = "Spremi";
			this.btnSpremi.UseVisualStyleBackColor = true;
			this.btnSpremi.Click += new System.EventHandler(this.btnSpremi_Click);
			// 
			// btnTest
			// 
			this.btnTest.Location = new System.Drawing.Point(181, 175);
			this.btnTest.Name = "btnTest";
			this.btnTest.Size = new System.Drawing.Size(75, 23);
			this.btnTest.TabIndex = 12;
			this.btnTest.Text = "Test";
			this.btnTest.UseVisualStyleBackColor = true;
			this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
			// 
			// btnOdustani
			// 
			this.btnOdustani.Location = new System.Drawing.Point(181, 204);
			this.btnOdustani.Name = "btnOdustani";
			this.btnOdustani.Size = new System.Drawing.Size(75, 23);
			this.btnOdustani.TabIndex = 13;
			this.btnOdustani.Text = "Odustani";
			this.btnOdustani.UseVisualStyleBackColor = true;
			this.btnOdustani.Click += new System.EventHandler(this.btnOdustani_Click);
			// 
			// FormProgramerska
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(310, 234);
			this.Controls.Add(this.btnOdustani);
			this.Controls.Add(this.btnTest);
			this.Controls.Add(this.btnSpremi);
			this.Controls.Add(this.L);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.chkIntegrated);
			this.Controls.Add(this.chkTrust);
			this.Controls.Add(this.chkEncrypt);
			this.Controls.Add(this.txtDatabase);
			this.Controls.Add(this.txtUser);
			this.Controls.Add(this.txtPassword);
			this.Controls.Add(this.txtServer);
			this.Name = "FormProgramerska";
			this.Text = "FormProgramerska";
			this.Load += new System.EventHandler(this.FormProgramerska_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtServer;
		private System.Windows.Forms.TextBox txtPassword;
		private System.Windows.Forms.TextBox txtUser;
		private System.Windows.Forms.TextBox txtDatabase;
		private System.Windows.Forms.CheckBox chkEncrypt;
		private System.Windows.Forms.CheckBox chkTrust;
		private System.Windows.Forms.CheckBox chkIntegrated;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label L;
		private System.Windows.Forms.Button btnSpremi;
		private System.Windows.Forms.Button btnTest;
		private System.Windows.Forms.Button btnOdustani;
	}
}