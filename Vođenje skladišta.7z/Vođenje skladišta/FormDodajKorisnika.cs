﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	public partial class FormDodajKorisnika : Form
	{
		string connectionString = ConnectionConfig.ConnectionString;

		public FormDodajKorisnika()
		{
			InitializeComponent();
		}

		private void FormDodajKorisnika_Load(object sender, EventArgs e)
		{
			this.BackColor = Color.FromArgb(40, 40, 40);
			this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

			// TextBox stil
			TextBox[] inputs = { txtUsername, txtLozinka };
			foreach (var t in inputs)
			{
				t.BackColor = Color.FromArgb(60, 60, 60);
				t.ForeColor = Color.White;
				t.BorderStyle = BorderStyle.FixedSingle;
			}

			// Label stil
			Label[] labels = { label1, label2 };
			foreach (var l in labels)
			{
				l.ForeColor = Color.White;
				l.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
			}

			// Gumbi
			Button[] buttons = { btnSpremi, btnOdustani };
			foreach (var b in buttons)
			{
				b.FlatStyle = FlatStyle.Flat;
				b.FlatAppearance.BorderSize = 0;
				b.ForeColor = Color.White;
				b.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
				b.BackColor = Color.FromArgb(70, 70, 70);
			}

			btnSpremi.BackColor = Color.FromArgb(40, 120, 60);
			btnOdustani.BackColor = Color.FromArgb(120, 40, 40);
		}

		private void btnSpremi_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrWhiteSpace(txtUsername.Text) ||
				string.IsNullOrWhiteSpace(txtLozinka.Text))
			{
				MessageBox.Show("Sva polja su obavezna.");
				return;
			}

			string hash = IzracunajHash(txtLozinka.Text);

			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();

					string query = "INSERT INTO Korisnici (Username, PasswordHash) VALUES (@u, @p)";
					SqlCommand cmd = new SqlCommand(query, conn);
					cmd.Parameters.AddWithValue("@u", txtUsername.Text);
					cmd.Parameters.AddWithValue("@p", hash);

					cmd.ExecuteNonQuery();
				}

				MessageBox.Show("Korisnik dodan.");
				this.Close();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška: " + ex.Message);
			}
		}

		private string IzracunajHash(string lozinka)
		{
			using (SHA256 sha = SHA256.Create())
			{
				byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(lozinka));
				StringBuilder sb = new StringBuilder();
				foreach (byte b in bytes)
					sb.Append(b.ToString("x2"));
				return sb.ToString();
			}
		}

		private void btnOdustani_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
