﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	partial class Form1
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			this.textboxKorisnickoIme = new System.Windows.Forms.TextBox();
			this.textboxLozinka = new System.Windows.Forms.TextBox();
			this.gumbPrijava = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// textboxKorisnickoIme
			// 
			this.textboxKorisnickoIme.Location = new System.Drawing.Point(275, 240);
			this.textboxKorisnickoIme.Name = "textboxKorisnickoIme";
			this.textboxKorisnickoIme.Size = new System.Drawing.Size(250, 25);
			this.textboxKorisnickoIme.TabIndex = 0;
			// 
			// textboxLozinka
			// 
			this.textboxLozinka.Location = new System.Drawing.Point(275, 280);
			this.textboxLozinka.Name = "textboxLozinka";
			this.textboxLozinka.PasswordChar = '*';
			this.textboxLozinka.Size = new System.Drawing.Size(250, 25);
			this.textboxLozinka.TabIndex = 1;
			// 
			// gumbPrijava
			// 
			this.gumbPrijava.Location = new System.Drawing.Point(300, 330);
			this.gumbPrijava.Name = "gumbPrijava";
			this.gumbPrijava.Size = new System.Drawing.Size(200, 35);
			this.gumbPrijava.TabIndex = 2;
			this.gumbPrijava.Text = "Prijava";
			this.gumbPrijava.UseVisualStyleBackColor = true;
			this.gumbPrijava.Click += new System.EventHandler(this.gumbPrijava_Click);
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(300, 375);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(200, 35);
			this.button5.TabIndex = 7;
			this.button5.Text = "Izlaz";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = global::Vođenje_skladišta.Properties.Resources.slikaskladište;
			this.pictureBox1.Location = new System.Drawing.Point(330, 60);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(140, 150);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 3;
			this.pictureBox1.TabStop = false;
			// 
			// Form1
			// 
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.button5);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.gumbPrijava);
			this.Controls.Add(this.textboxLozinka);
			this.Controls.Add(this.textboxKorisnickoIme);
			this.Name = "Form1";
			this.Text = "Prijava";
			this.Load += new System.EventHandler(this.Form1_Load);

			// ---------------------------------------------------------
			// MODERNI TAMNI GUI – AUTOMATSKI DODAN
			// ---------------------------------------------------------


			// ---------------------------------------------------------

			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		#endregion

		private System.Windows.Forms.TextBox textboxKorisnickoIme;
		private System.Windows.Forms.TextBox textboxLozinka;
		private System.Windows.Forms.Button gumbPrijava;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button button5;
	}
}

