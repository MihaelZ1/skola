﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	partial class FormDodajKorisnika
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			this.txtUsername = new System.Windows.Forms.TextBox();
			this.txtLozinka = new System.Windows.Forms.TextBox();
			this.btnSpremi = new System.Windows.Forms.Button();
			this.btnOdustani = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtUsername
			// 
			this.txtUsername.Location = new System.Drawing.Point(150, 70);
			this.txtUsername.Name = "txtUsername";
			this.txtUsername.Size = new System.Drawing.Size(180, 23);
			this.txtUsername.TabIndex = 0;
			// 
			// txtLozinka
			// 
			this.txtLozinka.Location = new System.Drawing.Point(150, 120);
			this.txtLozinka.Name = "txtLozinka";
			this.txtLozinka.Size = new System.Drawing.Size(180, 23);
			this.txtLozinka.TabIndex = 1;
			this.txtLozinka.PasswordChar = '*';
			// 
			// btnSpremi
			// 
			this.btnSpremi.Location = new System.Drawing.Point(360, 70);
			this.btnSpremi.Name = "btnSpremi";
			this.btnSpremi.Size = new System.Drawing.Size(120, 35);
			this.btnSpremi.TabIndex = 2;
			this.btnSpremi.Text = "Spremi";
			this.btnSpremi.UseVisualStyleBackColor = true;
			this.btnSpremi.Click += new System.EventHandler(this.btnSpremi_Click);
			// 
			// btnOdustani
			// 
			this.btnOdustani.Location = new System.Drawing.Point(360, 120);
			this.btnOdustani.Name = "btnOdustani";
			this.btnOdustani.Size = new System.Drawing.Size(120, 35);
			this.btnOdustani.TabIndex = 3;
			this.btnOdustani.Text = "Odustani";
			this.btnOdustani.UseVisualStyleBackColor = true;
			this.btnOdustani.Click += new System.EventHandler(this.btnOdustani_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(60, 73);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(66, 15);
			this.label1.TabIndex = 4;
			this.label1.Text = "Username:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(60, 123);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(61, 15);
			this.label2.TabIndex = 5;
			this.label2.Text = "Password:";
			// 
			// FormDodajKorisnika
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(520, 220);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnOdustani);
			this.Controls.Add(this.btnSpremi);
			this.Controls.Add(this.txtLozinka);
			this.Controls.Add(this.txtUsername);
			this.Name = "FormDodajKorisnika";
			this.Text = "Dodavanje korisnika";
			this.Load += new System.EventHandler(this.FormDodajKorisnika_Load);

			// ---------------------------------------------------------
			// MODERNI TAMNI GUI – AUTOMATSKI DODAN
			// ---------------------------------------------------------

			

			// ---------------------------------------------------------

			this.ResumeLayout(false);
			this.PerformLayout();
		}

		#endregion

		private System.Windows.Forms.TextBox txtUsername;
		private System.Windows.Forms.TextBox txtLozinka;
		private System.Windows.Forms.Button btnSpremi;
		private System.Windows.Forms.Button btnOdustani;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
	}
}
