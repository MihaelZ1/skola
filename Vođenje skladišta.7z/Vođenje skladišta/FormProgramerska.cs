﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	public partial class FormProgramerska : Form
	{
		public FormProgramerska()
		{
			InitializeComponent();
		}

		private void FormProgramerska_Load(object sender, EventArgs e)
		{
			try
			{
				var builder = new SqlConnectionStringBuilder(ConnectionConfig.ConnectionString);

				txtServer.Text = builder.DataSource;
				txtDatabase.Text = builder.InitialCatalog;

				chkIntegrated.Checked = builder.IntegratedSecurity;

				if (!builder.IntegratedSecurity)
				{
					txtUser.Text = builder.UserID;
					txtPassword.Text = builder.Password;
				}

				chkEncrypt.Checked = builder.Encrypt;
				chkTrust.Checked = builder.TrustServerCertificate;
			}
			catch
			{
				MessageBox.Show("Ne mogu učitati trenutni connection string.");
			}
		}

		private void btnSpremi_Click(object sender, EventArgs e)
		{
			try
			{
				var builder = new SqlConnectionStringBuilder();

				builder.DataSource = txtServer.Text;
				builder.InitialCatalog = txtDatabase.Text;

				if (chkIntegrated.Checked)
				{
					builder.IntegratedSecurity = true;
				}
				else
				{
					builder.UserID = txtUser.Text;
					builder.Password = L.Text;
				}

				builder.Encrypt = chkEncrypt.Checked;
				builder.TrustServerCertificate = chkTrust.Checked;

				ConnectionConfig.ConnectionString = builder.ToString();

				MessageBox.Show("Postavke spremljene!");
				this.Close();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška: " + ex.Message);
			}
		}

		private void btnTest_Click(object sender, EventArgs e)
		{
			try
			{
				var builder = new SqlConnectionStringBuilder();

				builder.DataSource = txtServer.Text;
				builder.InitialCatalog = txtDatabase.Text;

				if (chkIntegrated.Checked)
				{
					builder.IntegratedSecurity = true;
				}
				else
				{
					builder.UserID = txtUser.Text;
					builder.Password = txtPassword.Text;
				}

				builder.Encrypt = chkEncrypt.Checked;
				builder.TrustServerCertificate = chkTrust.Checked;

				using (SqlConnection conn = new SqlConnection(builder.ToString()))
				{
					conn.Open();
				}

				MessageBox.Show("Konekcija uspješna!");
			}
			catch (Exception ex)
			{
				MessageBox.Show("Neuspješna konekcija: " + ex.Message);
			}
		}

		private void btnOdustani_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
