﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	public partial class FormDodajPravo : Form
	{
		private int idKorisnik;
		string connectionString = ConnectionConfig.ConnectionString;

		public FormDodajPravo(int korisnikId)
		{
			InitializeComponent();
			idKorisnik = korisnikId;
		}

		private void FormDodajPravo_Load(object sender, EventArgs e)
		{
			UcitajPrava();
		}

		private void UcitajPrava()
		{
			using (SqlConnection conn = new SqlConnection(connectionString))
			{
				conn.Open();
				SqlDataAdapter da = new SqlDataAdapter(
		"SELECT IdPravo, NazivPrava FROM Prava WHERE NazivPrava <> 'Programer'", conn);


				DataTable dt = new DataTable();
				da.Fill(dt);

				cmbPrava.DataSource = dt;
				cmbPrava.DisplayMember = "NazivPrava";
				cmbPrava.ValueMember = "IdPravo";
			}
		}

		private void btnDodaj_Click(object sender, EventArgs e)
		{
			// Provjera je li nešto uopće odabrano u ComboBoxu
			if (cmbPrava.SelectedValue == null)
			{
				MessageBox.Show("Molimo odaberite pravo s popisa.");
				return;
			}

			int idPravo = Convert.ToInt32(cmbPrava.SelectedValue);

			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();

					// 1. KORAK: Provjera duplikata
					string provjeraQuery = "SELECT COUNT(*) FROM KorisniciPrava WHERE IdKorisnik = @k AND IdPravo = @p";
					using (SqlCommand provjeraCmd = new SqlCommand(provjeraQuery, conn))
					{
						provjeraCmd.Parameters.AddWithValue("@k", idKorisnik);
						provjeraCmd.Parameters.AddWithValue("@p", idPravo);

						int postoji = (int)provjeraCmd.ExecuteScalar();

						if (postoji > 0)
						{
							MessageBox.Show("Korisnik već ima dodijeljeno ovo pravo!", "Upozorenje", MessageBoxButtons.OK, MessageBoxIcon.Warning);
							return; // Prekida metodu, ne ide dalje na INSERT
						}
					}

					// 2. KORAK: Ako ne postoji, dodaj ga
					string insertQuery = "INSERT INTO KorisniciPrava (IdKorisnik, IdPravo) VALUES (@k, @p)";
					using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
					{
						cmd.Parameters.AddWithValue("@k", idKorisnik);
						cmd.Parameters.AddWithValue("@p", idPravo);
						cmd.ExecuteNonQuery();
					}

					MessageBox.Show("Pravo uspješno dodano.");
					this.Close();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri spremanju u bazu: " + ex.Message);
			}
		}

		private void btnOdustani_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
