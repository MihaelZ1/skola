﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	partial class FormPregledNarudzbi
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			this.dgvNarudzbe = new System.Windows.Forms.DataGridView();
			this.dgvStavke = new System.Windows.Forms.DataGridView();
			this.btnOsvjezi = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dgvNarudzbe)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgvStavke)).BeginInit();
			this.SuspendLayout();
			// 
			// dgvNarudzbe
			// 
			this.dgvNarudzbe.Location = new System.Drawing.Point(12, 47);
			this.dgvNarudzbe.Name = "dgvNarudzbe";
			this.dgvNarudzbe.Size = new System.Drawing.Size(578, 150);
			this.dgvNarudzbe.TabIndex = 0;
			this.dgvNarudzbe.SelectionChanged += new System.EventHandler(this.dgvNarudzbe_SelectionChanged);
			// 
			// dgvStavke
			// 
			this.dgvStavke.Location = new System.Drawing.Point(12, 237);
			this.dgvStavke.Name = "dgvStavke";
			this.dgvStavke.Size = new System.Drawing.Size(578, 150);
			this.dgvStavke.TabIndex = 1;
			// 
			// btnOsvjezi
			// 
			this.btnOsvjezi.Location = new System.Drawing.Point(613, 203);
			this.btnOsvjezi.Name = "btnOsvjezi";
			this.btnOsvjezi.Size = new System.Drawing.Size(120, 35);
			this.btnOsvjezi.TabIndex = 2;
			this.btnOsvjezi.Text = "Osvježi";
			this.btnOsvjezi.UseVisualStyleBackColor = true;
			this.btnOsvjezi.Click += new System.EventHandler(this.btnOsvjezi_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(613, 250);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(120, 35);
			this.button1.TabIndex = 3;
			this.button1.Text = "Izlaz";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// FormPregledNarudzbi
			// 
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.btnOsvjezi);
			this.Controls.Add(this.dgvStavke);
			this.Controls.Add(this.dgvNarudzbe);
			this.Name = "FormPregledNarudzbi";
			this.Text = "Pregled narudžbi";
			this.Load += new System.EventHandler(this.FormPregledNarudzbi_Load);

			// ---------------------------------------------------------
			// MODERNI TAMNI GUI – AUTOMATSKI DODAN
			// ---------------------------------------------------------

			

			// ---------------------------------------------------------

			((System.ComponentModel.ISupportInitialize)(this.dgvNarudzbe)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgvStavke)).EndInit();
			this.ResumeLayout(false);
		}

		#endregion

		private System.Windows.Forms.DataGridView dgvNarudzbe;
		private System.Windows.Forms.DataGridView dgvStavke;
		private System.Windows.Forms.Button btnOsvjezi;
		private System.Windows.Forms.Button button1;
	}
}
