﻿public static class ConnectionConfig
{
	public static string ConnectionString { get; set; } =
		@"Data Source=localhost\sqlexpress;Initial Catalog=skladisteDB;User ID=zeleznjak;Password=zeleznjak;Encrypt=True;TrustServerCertificate=True";
}
