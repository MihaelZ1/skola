﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	partial class FormIzmjena
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.lblNaziv = new System.Windows.Forms.Label();
			this.txtNaziv = new System.Windows.Forms.TextBox();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.lblOpis = new System.Windows.Forms.Label();
			this.txtOpis = new System.Windows.Forms.TextBox();
			this.lblCijena = new System.Windows.Forms.Label();
			this.txtCijena = new System.Windows.Forms.TextBox();
			this.btnSpremi = new System.Windows.Forms.Button();
			this.btnOdustani = new System.Windows.Forms.Button();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.btnIzlaz = new System.Windows.Forms.Button();
			this.txtKolicina = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txtId = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// lblNaziv
			// 
			this.lblNaziv.AutoSize = true;
			this.lblNaziv.Location = new System.Drawing.Point(64, 229);
			this.lblNaziv.Name = "lblNaziv";
			this.lblNaziv.Size = new System.Drawing.Size(71, 13);
			this.lblNaziv.TabIndex = 0;
			this.lblNaziv.Text = "Naziv artikla:";
			// 
			// txtNaziv
			// 
			this.txtNaziv.Location = new System.Drawing.Point(67, 245);
			this.txtNaziv.Name = "txtNaziv";
			this.txtNaziv.Size = new System.Drawing.Size(337, 20);
			this.txtNaziv.TabIndex = 1;
			// 
			// lblOpis
			// 
			this.lblOpis.AutoSize = true;
			this.lblOpis.Location = new System.Drawing.Point(64, 268);
			this.lblOpis.Name = "lblOpis";
			this.lblOpis.Size = new System.Drawing.Size(31, 13);
			this.lblOpis.TabIndex = 3;
			this.lblOpis.Text = "Opis:";
			// 
			// txtOpis
			// 
			this.txtOpis.Location = new System.Drawing.Point(67, 284);
			this.txtOpis.Multiline = true;
			this.txtOpis.Name = "txtOpis";
			this.txtOpis.Size = new System.Drawing.Size(160, 49);
			this.txtOpis.TabIndex = 4;
			// 
			// lblCijena
			// 
			this.lblCijena.AutoSize = true;
			this.lblCijena.Location = new System.Drawing.Point(64, 345);
			this.lblCijena.Name = "lblCijena";
			this.lblCijena.Size = new System.Drawing.Size(39, 13);
			this.lblCijena.TabIndex = 5;
			this.lblCijena.Text = "Cijena:";
			// 
			// txtCijena
			// 
			this.txtCijena.Location = new System.Drawing.Point(67, 364);
			this.txtCijena.Name = "txtCijena";
			this.txtCijena.Size = new System.Drawing.Size(160, 20);
			this.txtCijena.TabIndex = 6;
			// 
			// btnSpremi
			// 
			this.btnSpremi.Location = new System.Drawing.Point(457, 294);
			this.btnSpremi.Name = "btnSpremi";
			this.btnSpremi.Size = new System.Drawing.Size(75, 23);
			this.btnSpremi.TabIndex = 7;
			this.btnSpremi.Text = "Spremi";
			this.btnSpremi.UseVisualStyleBackColor = true;
			this.btnSpremi.Click += new System.EventHandler(this.btnSpremi_Click);
			// 
			// btnOdustani
			// 
			this.btnOdustani.Location = new System.Drawing.Point(538, 294);
			this.btnOdustani.Name = "btnOdustani";
			this.btnOdustani.Size = new System.Drawing.Size(75, 23);
			this.btnOdustani.TabIndex = 8;
			this.btnOdustani.Text = "Odustani";
			this.btnOdustani.UseVisualStyleBackColor = true;
			this.btnOdustani.Click += new System.EventHandler(this.btnOdustani_Click);
			// 
			// dataGridView1
			// 
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(67, 23);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.Size = new System.Drawing.Size(665, 150);
			this.dataGridView1.TabIndex = 9;
			this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
			// 
			// btnIzlaz
			// 
			this.btnIzlaz.Location = new System.Drawing.Point(619, 294);
			this.btnIzlaz.Name = "btnIzlaz";
			this.btnIzlaz.Size = new System.Drawing.Size(75, 23);
			this.btnIzlaz.TabIndex = 10;
			this.btnIzlaz.Text = "Izlaz";
			this.btnIzlaz.UseVisualStyleBackColor = true;
			this.btnIzlaz.Click += new System.EventHandler(this.btnIzlaz_Click);
			// 
			// txtKolicina
			// 
			this.txtKolicina.Location = new System.Drawing.Point(67, 418);
			this.txtKolicina.Name = "txtKolicina";
			this.txtKolicina.Size = new System.Drawing.Size(107, 20);
			this.txtKolicina.TabIndex = 11;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(64, 402);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(47, 13);
			this.label1.TabIndex = 12;
			this.label1.Text = "Količina:";
			// 
			// txtId
			// 
			this.txtId.Location = new System.Drawing.Point(67, 197);
			this.txtId.Name = "txtId";
			this.txtId.Size = new System.Drawing.Size(100, 20);
			this.txtId.TabIndex = 13;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(64, 176);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(19, 13);
			this.label2.TabIndex = 14;
			this.label2.Text = "Id:";
			// 
			// FormIzmjena
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtId);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtKolicina);
			this.Controls.Add(this.btnIzlaz);
			this.Controls.Add(this.dataGridView1);
			this.Controls.Add(this.btnOdustani);
			this.Controls.Add(this.btnSpremi);
			this.Controls.Add(this.txtCijena);
			this.Controls.Add(this.lblCijena);
			this.Controls.Add(this.txtOpis);
			this.Controls.Add(this.lblOpis);
			this.Controls.Add(this.txtNaziv);
			this.Controls.Add(this.lblNaziv);
			this.Name = "FormIzmjena";
			this.Text = "Izmjena artikla";
			this.Load += new System.EventHandler(this.FormIzmjena_Load);

			// ---------------------------------------------------------
			// MODERNI TAMNI GUI – AUTOMATSKI DODAN
			// ---------------------------------------------------------

			

			// ---------------------------------------------------------

			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		#endregion

		private System.Windows.Forms.Label lblNaziv;
		private System.Windows.Forms.TextBox txtNaziv;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.Label lblOpis;
		private System.Windows.Forms.TextBox txtOpis;
		private System.Windows.Forms.Label lblCijena;
		private System.Windows.Forms.TextBox txtCijena;
		private System.Windows.Forms.Button btnSpremi;
		private System.Windows.Forms.Button btnOdustani;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.Button btnIzlaz;
		private System.Windows.Forms.TextBox txtKolicina;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtId;
		private System.Windows.Forms.Label label2;
	}
}
