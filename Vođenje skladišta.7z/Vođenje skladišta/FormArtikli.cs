﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	public partial class FormArtikli : Form
	{

		string connectionString = ConnectionConfig.ConnectionString;

		public FormArtikli()
		{
			InitializeComponent();
		}

		private void FormArtikli_Load(object sender, EventArgs e)
		{
			try
			{
				using (SqlConnection conn = new SqlConnection(connectionString))
				{
					conn.Open();
					SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Artikli", conn);
					DataTable dt = new DataTable();
					da.Fill(dt);
					dgvArtikli.DataSource = dt;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri spajanju na bazu: " + ex.Message);
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
