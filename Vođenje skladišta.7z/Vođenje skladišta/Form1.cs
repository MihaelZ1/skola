﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Vođenje_skladišta
{
	public partial class Form1 : Form
	{
		string connectionString = @"Data Source=localhost\sqlexpress;Initial Catalog=skladisteDB;User ID=zeleznjak;Password=zeleznjak;Encrypt=True;TrustServerCertificate=True";

		public Form1()
		{
			InitializeComponent();

		}

		private void Form1_Load(object sender, EventArgs e)
		{

			this.BackColor = Color.FromArgb(40, 40, 40);
			this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);

			// TextBox stil
			System.Windows.Forms.TextBox[] inputs = { textboxKorisnickoIme, textboxLozinka };

			foreach (var t in inputs)
			{
				t.BackColor = Color.FromArgb(60, 60, 60);
				t.ForeColor = Color.White;
				t.BorderStyle = BorderStyle.FixedSingle;
			}

			// Gumbi
			System.Windows.Forms.Button[] buttons = { gumbPrijava, button5 };

			foreach (var b in buttons)
			{
				b.FlatStyle = FlatStyle.Flat;
				b.FlatAppearance.BorderSize = 0;
				b.ForeColor = Color.White;
				b.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
				b.BackColor = Color.FromArgb(70, 70, 70);
			}

			gumbPrijava.BackColor = Color.FromArgb(40, 120, 60);
			button5.BackColor = Color.FromArgb(120, 40, 40);

			// PictureBox border
			this.pictureBox1.BackColor = Color.FromArgb(50, 50, 50);
		}

		private void gumbPrijava_Click(object sender, EventArgs e)
		{
			string username = textboxKorisnickoIme.Text;
			string lozinka = textboxLozinka.Text;

			if (ProvjeriKorisnika(username, lozinka))
			{
				// Ako je prijava uspješna, otvori Form2
				Form2 mainForm = new Form2(username);
				mainForm.Show();
				this.Hide();
			}
			else
			{
				MessageBox.Show("Neispravni podaci! Pokušajte ponovno.");
			}

		}
		private bool ProvjeriKorisnika(string username, string lozinka)
		{
			string hash = IzracunajHash(lozinka);

			using (SqlConnection conn = new SqlConnection(connectionString))
			{
				conn.Open();
				string query = "SELECT COUNT(*) FROM Korisnici WHERE Username=@user AND PasswordHash=@hash";
				SqlCommand cmd = new SqlCommand(query, conn);
				cmd.Parameters.AddWithValue("@user", username);
				cmd.Parameters.AddWithValue("@hash", hash);

				int count = (int)cmd.ExecuteScalar();
				return count > 0;
			}
		}
		private string IzracunajHash(string lozinka)
		{
			using (SHA256 sha256 = SHA256.Create())
			{
				byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(lozinka));
				StringBuilder builder = new StringBuilder();
				foreach (byte b in bytes)
					builder.Append(b.ToString("x2"));
				return builder.ToString();


			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			DialogResult rezultat = MessageBox.Show(
			"Želite li stvarno izaći iz programa?",
			 "Potvrda izlaza",
  MessageBoxButtons.YesNo,
  MessageBoxIcon.Question);

			if (rezultat == DialogResult.Yes)
			{
				Application.Exit();
			}
		}
	}
}
