﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Vođenje_skladišta
{
	partial class FormNovaNarudzba
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			this.cmbArtikl = new System.Windows.Forms.ComboBox();
			this.cmbKolicina = new System.Windows.Forms.ComboBox();
			this.txtCijena = new System.Windows.Forms.TextBox();
			this.txtUkupno = new System.Windows.Forms.TextBox();
			this.btnSpremiNarudzbu = new System.Windows.Forms.Button();
			this.btnOdustani = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.Količina = new System.Windows.Forms.Label();
			this.btnDodajStavku = new System.Windows.Forms.Button();
			this.dgvStavke = new System.Windows.Forms.DataGridView();
			this.tb_ime = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.dgvStavke)).BeginInit();
			this.SuspendLayout();
			// 
			// cmbArtikl
			// 
			this.cmbArtikl.Location = new System.Drawing.Point(12, 53);
			this.cmbArtikl.Name = "cmbArtikl";
			this.cmbArtikl.Size = new System.Drawing.Size(140, 21);
			this.cmbArtikl.TabIndex = 0;
			this.cmbArtikl.SelectedIndexChanged += new System.EventHandler(this.cmbArtikl_SelectedIndexChanged);
			// 
			// cmbKolicina
			// 
			this.cmbKolicina.Location = new System.Drawing.Point(176, 53);
			this.cmbKolicina.Name = "cmbKolicina";
			this.cmbKolicina.Size = new System.Drawing.Size(140, 21);
			this.cmbKolicina.TabIndex = 1;
			// 
			// txtCijena
			// 
			this.txtCijena.Location = new System.Drawing.Point(12, 177);
			this.txtCijena.Name = "txtCijena";
			this.txtCijena.ReadOnly = true;
			this.txtCijena.Size = new System.Drawing.Size(140, 20);
			this.txtCijena.TabIndex = 2;
			// 
			// txtUkupno
			// 
			this.txtUkupno.Location = new System.Drawing.Point(183, 177);
			this.txtUkupno.Name = "txtUkupno";
			this.txtUkupno.ReadOnly = true;
			this.txtUkupno.Size = new System.Drawing.Size(140, 20);
			this.txtUkupno.TabIndex = 3;
			// 
			// btnSpremiNarudzbu
			// 
			this.btnSpremiNarudzbu.Location = new System.Drawing.Point(12, 288);
			this.btnSpremiNarudzbu.Name = "btnSpremiNarudzbu";
			this.btnSpremiNarudzbu.Size = new System.Drawing.Size(120, 35);
			this.btnSpremiNarudzbu.TabIndex = 4;
			this.btnSpremiNarudzbu.Text = "Spremi";
			this.btnSpremiNarudzbu.UseVisualStyleBackColor = true;
			this.btnSpremiNarudzbu.Click += new System.EventHandler(this.btnSpremiNarudzbu_Click);
			// 
			// btnOdustani
			// 
			this.btnOdustani.Location = new System.Drawing.Point(203, 288);
			this.btnOdustani.Name = "btnOdustani";
			this.btnOdustani.Size = new System.Drawing.Size(120, 35);
			this.btnOdustani.TabIndex = 5;
			this.btnOdustani.Text = "Odustani";
			this.btnOdustani.UseVisualStyleBackColor = true;
			this.btnOdustani.Click += new System.EventHandler(this.btnOdustani_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(12, 154);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(120, 20);
			this.label1.TabIndex = 16;
			this.label1.Text = "Cijena artikla:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(180, 154);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(160, 20);
			this.label2.TabIndex = 15;
			this.label2.Text = "Ukupna cijena:";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(12, 30);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(80, 20);
			this.label3.TabIndex = 14;
			this.label3.Text = "Artikl:";
			// 
			// Količina
			// 
			this.Količina.Location = new System.Drawing.Point(173, 30);
			this.Količina.Name = "Količina";
			this.Količina.Size = new System.Drawing.Size(80, 20);
			this.Količina.TabIndex = 13;
			this.Količina.Text = "Količina:";
			// 
			// btnDodajStavku
			// 
			this.btnDodajStavku.Location = new System.Drawing.Point(12, 229);
			this.btnDodajStavku.Name = "btnDodajStavku";
			this.btnDodajStavku.Size = new System.Drawing.Size(140, 30);
			this.btnDodajStavku.TabIndex = 10;
			this.btnDodajStavku.Text = "Dodaj stavku";
			this.btnDodajStavku.UseVisualStyleBackColor = true;
			this.btnDodajStavku.Click += new System.EventHandler(this.btnDodajStavku_Click);
			// 
			// dgvStavke
			// 
			this.dgvStavke.Location = new System.Drawing.Point(346, 79);
			this.dgvStavke.Name = "dgvStavke";
			this.dgvStavke.Size = new System.Drawing.Size(567, 203);
			this.dgvStavke.TabIndex = 11;
			// 
			// tb_ime
			// 
			this.tb_ime.Location = new System.Drawing.Point(12, 117);
			this.tb_ime.Name = "tb_ime";
			this.tb_ime.Size = new System.Drawing.Size(140, 20);
			this.tb_ime.TabIndex = 12;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(9, 101);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(140, 20);
			this.label4.TabIndex = 0;
			this.label4.Text = "Ime na narudžbi:";
			// 
			// FormNovaNarudzba
			// 
			this.ClientSize = new System.Drawing.Size(925, 450);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.tb_ime);
			this.Controls.Add(this.dgvStavke);
			this.Controls.Add(this.btnDodajStavku);
			this.Controls.Add(this.Količina);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnOdustani);
			this.Controls.Add(this.btnSpremiNarudzbu);
			this.Controls.Add(this.txtUkupno);
			this.Controls.Add(this.txtCijena);
			this.Controls.Add(this.cmbKolicina);
			this.Controls.Add(this.cmbArtikl);
			this.Name = "FormNovaNarudzba";
			this.Text = "Nova narudžba";
			this.Load += new System.EventHandler(this.FormNovaNarudzba_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgvStavke)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ComboBox cmbArtikl;
		private System.Windows.Forms.ComboBox cmbKolicina;
		private System.Windows.Forms.TextBox txtCijena;
		private System.Windows.Forms.TextBox txtUkupno;
		private System.Windows.Forms.Button btnSpremiNarudzbu;
		private System.Windows.Forms.Button btnOdustani;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label Količina;
		private System.Windows.Forms.Button btnDodajStavku;
		private System.Windows.Forms.DataGridView dgvStavke;
		private System.Windows.Forms.TextBox tb_ime;
		private System.Windows.Forms.Label label4;
	}
}
