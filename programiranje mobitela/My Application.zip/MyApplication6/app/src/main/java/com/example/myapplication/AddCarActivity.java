package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class AddCarActivity extends AppCompatActivity {

    EditText inMarka, inBrzina, inGodina;
    Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_car);

        inMarka = findViewById(R.id.inMarka);
        inBrzina = findViewById(R.id.inBrzina);
        inGodina = findViewById(R.id.inGodina);
        btnSave = findViewById(R.id.btnSave);

        btnSave.setOnClickListener(v -> saveCar());
    }

    void saveCar() {
        new Thread(() -> {
            try {
                URL url = new URL("http://10.0.2.2:80/se/server.php");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json; utf-8");
                con.setDoOutput(true);

                JSONObject obj = new JSONObject();
                obj.put("marka", inMarka.getText().toString());
                obj.put("max_brzina", inBrzina.getText().toString());
                obj.put("god_proizvodnje", inGodina.getText().toString());

                OutputStream os = con.getOutputStream();
                os.write(obj.toString().getBytes("UTF-8"));
                os.close();

                InputStream is = con.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));

                StringBuilder sb = new StringBuilder();
                String line;

                while ((line = br.readLine()) != null)
                    sb.append(line);

                runOnUiThread(() -> {
                    Toast.makeText(this, "Auto dodan!", Toast.LENGTH_SHORT).show();
                    finish();
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                });

            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Greška!", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }
}
