package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DeleteCarActivity extends AppCompatActivity {

    Button btnYes, btnNo;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_car);

        id = getIntent().getStringExtra("id");

        btnYes = findViewById(R.id.btnYes);
        btnNo = findViewById(R.id.btnNo);

        btnYes.setOnClickListener(v -> deleteCar());
        btnNo.setOnClickListener(v -> finish());
    }

    void deleteCar() {
        new Thread(() -> {
            try {
                URL url = new URL("http://10.0.2.2:80/se/server.php");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("DELETE");
                con.setRequestProperty("Content-Type", "application/json; utf-8");
                con.setRequestProperty("Accept", "application/json");
                con.setDoOutput(true);

                // JSON koji server očekuje
                JSONObject obj = new JSONObject();
                obj.put("id", id);

                OutputStream os = con.getOutputStream();
                os.write(obj.toString().getBytes());
                os.flush();
                os.close();

                int code = con.getResponseCode();

                runOnUiThread(() -> {
                    if (code == 200) {
                        Toast.makeText(this, "Auto obrisan!", Toast.LENGTH_SHORT).show();
                        finish();
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                    } else {
                        Toast.makeText(this, "Greška: " + code, Toast.LENGTH_SHORT).show();
                    }
                });

            } catch (Exception e) {
                runOnUiThread(() ->
                        Toast.makeText(this, "Greška pri brisanju!", Toast.LENGTH_SHORT).show()
                );
            }
        }).start();
    }
}
