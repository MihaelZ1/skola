package com.example.myapplication.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.models.car;

import java.util.List;

public class DeleteListAdapter extends RecyclerView.Adapter<DeleteListAdapter.Holder> {

    public interface OnCarClick {
        void onClick(car c);
    }

    List<car> list;
    OnCarClick listener;

    public DeleteListAdapter(List<car> list, OnCarClick listener) {
        this.list = list;
        this.listener = listener;
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_car, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(Holder h, int i) {
        car c = list.get(i);

        h.marka.setText(c.marka);
        h.brzina.setText("Max brzina: " + c.max_brzina);
        h.godina.setText("Godina: " + c.god_proizvodnje);

        h.itemView.setOnClickListener(v -> listener.onClick(c));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class Holder extends RecyclerView.ViewHolder {
        TextView marka, brzina, godina;

        Holder(View v) {
            super(v);
            marka = v.findViewById(R.id.txtMarka);
            brzina = v.findViewById(R.id.txtBrzina);
            godina = v.findViewById(R.id.txtGodina);
        }
    }
}
