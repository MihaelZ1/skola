package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.adapters.DeleteListAdapter;
import com.example.myapplication.models.car;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class DeleteCarListActivity extends AppCompatActivity {

    RecyclerView recycler;
    ArrayList<car> cars = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_car_list);

        recycler = findViewById(R.id.recyclerDelete);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        loadCars();
    }

    void loadCars() {
        new Thread(() -> {
            try {
                URL url = new URL("http://10.0.2.2:80/se/server.php");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");

                InputStream is = con.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));

                StringBuilder sb = new StringBuilder();
                String line;

                while ((line = br.readLine()) != null)
                    sb.append(line);

                JSONObject root = new JSONObject(sb.toString());
                JSONArray arr = new JSONArray(root.getString("json_data"));

                cars.clear();

                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    cars.add(new car(
                            o.getString("id"),
                            o.getString("marka"),
                            o.getString("max_brzina"),
                            o.getString("god_proizvodnje")
                    ));
                }

                runOnUiThread(() -> {
                    recycler.setAdapter(new DeleteListAdapter(cars, car -> {
                        Intent i = new Intent(DeleteCarListActivity.this, DeleteCarActivity.class);
                        i.putExtra("id", car.id);
                        startActivity(i);
                        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                    }));
                });

            } catch (Exception ignored) {}
        }).start();
    }
}
