package com.example.myapplication.adapters;

import com.example.myapplication.models.car;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

import java.util.List;

public class CarAdapter extends RecyclerView.Adapter<CarAdapter.Holder> {

    List<car> list;

    public CarAdapter(List<car> list) {
        this.list = list;
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_car, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(Holder h, int i) {
        car c = list.get(i);
        h.marka.setText(c.marka);
        h.brzina.setText("Max brzina: " + c.max_brzina);
        h.godina.setText("Godina: " + c.god_proizvodnje);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class Holder extends RecyclerView.ViewHolder {
        TextView marka, brzina, godina;

        Holder(View v) {
            super(v);
            marka = v.findViewById(R.id.txtMarka);
            brzina = v.findViewById(R.id.txtBrzina);
            godina = v.findViewById(R.id.txtGodina);
        }
    }
}
