package com.example.myapplication.models;

public class car {
    public String id, marka, max_brzina, god_proizvodnje;

    public car(String id, String marka, String max_brzina, String god_proizvodnje) {
        this.id = id;
        this.marka = marka;
        this.max_brzina = max_brzina;
        this.god_proizvodnje = god_proizvodnje;
    }
}
