package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class EditCarActivity extends AppCompatActivity {

    EditText inMarka, inBrzina, inGodina;
    Button btnSave;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_car);

        id = getIntent().getStringExtra("id");

        inMarka = findViewById(R.id.inMarka);
        inBrzina = findViewById(R.id.inBrzina);
        inGodina = findViewById(R.id.inGodina);
        btnSave = findViewById(R.id.btnSave);

        // popuni polja postojećim vrijednostima
        inMarka.setText(getIntent().getStringExtra("marka"));
        inBrzina.setText(getIntent().getStringExtra("brzina"));
        inGodina.setText(getIntent().getStringExtra("godina"));

        btnSave.setOnClickListener(v -> updateCar());
    }

    void updateCar() {
        new Thread(() -> {
            try {
                URL url = new URL("http://10.0.2.2:80/se/server.php");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("PUT");
                con.setRequestProperty("Content-Type", "application/json; utf-8");
                con.setRequestProperty("Accept", "application/json");
                con.setDoOutput(true);

                JSONObject obj = new JSONObject();
                obj.put("id", id);
                obj.put("marka", inMarka.getText().toString());
                obj.put("max_brzina", Integer.parseInt(inBrzina.getText().toString()));
                obj.put("god_proizvodnje", Integer.parseInt(inGodina.getText().toString()));

                OutputStream os = con.getOutputStream();
                os.write(obj.toString().getBytes());
                os.flush();
                os.close();

                int code = con.getResponseCode();

                runOnUiThread(() -> {
                    if (code == 200) {
                        Toast.makeText(this, "Auto ažuriran!", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(this, "Greška: " + code, Toast.LENGTH_SHORT).show();
                    }
                });

            } catch (Exception e) {
                runOnUiThread(() ->
                        Toast.makeText(this, "Greška pri uređivanju!", Toast.LENGTH_SHORT).show()
                );
            }
        }).start();
    }



}
